import React, { useState } from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import PaymentForm from '../../components/ui/PaymentForm';

export default function DepositPage() {
  const [selectedMethod, setSelectedMethod] = useState<'pix' | 'credit_card' | 'bank_transfer' | 'crypto'>('pix');
  const [amount, setAmount] = useState('100');
  const [showQRCode, setShowQRCode] = useState(false);

  const handleSubmit = () => {
    if (selectedMethod === 'pix') {
      setShowQRCode(true);
    } else {
      // Implementar lógica para outros métodos
      alert('Processando pagamento...');
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Deposit Page */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h1 className="text-3xl font-bold mb-8">
            Realizar <span className="text-green-500">Depósito</span>
          </h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left Column - Payment Methods */}
            <div className="md:col-span-1">
              <div className="bg-gray-800 rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Métodos de Pagamento</h2>
                <div className="space-y-2">
                  <button 
                    className={`w-full text-left p-3 rounded-md flex items-center space-x-3 ${selectedMethod === 'pix' ? 'bg-green-900 border border-green-500' : 'bg-gray-700 hover:bg-gray-600'}`}
                    onClick={() => setSelectedMethod('pix')}
                  >
                    <span className="text-2xl">🔄</span>
                    <div>
                      <p className="font-bold">PIX</p>
                      <p className="text-xs text-gray-400">Instantâneo, sem taxas</p>
                    </div>
                  </button>
                  
                  <button 
                    className={`w-full text-left p-3 rounded-md flex items-center space-x-3 ${selectedMethod === 'credit_card' ? 'bg-green-900 border border-green-500' : 'bg-gray-700 hover:bg-gray-600'}`}
                    onClick={() => setSelectedMethod('credit_card')}
                  >
                    <span className="text-2xl">💳</span>
                    <div>
                      <p className="font-bold">Cartão de Crédito</p>
                      <p className="text-xs text-gray-400">Instantâneo, taxa de 2.5%</p>
                    </div>
                  </button>
                  
                  <button 
                    className={`w-full text-left p-3 rounded-md flex items-center space-x-3 ${selectedMethod === 'bank_transfer' ? 'bg-green-900 border border-green-500' : 'bg-gray-700 hover:bg-gray-600'}`}
                    onClick={() => setSelectedMethod('bank_transfer')}
                  >
                    <span className="text-2xl">🏦</span>
                    <div>
                      <p className="font-bold">Transferência Bancária</p>
                      <p className="text-xs text-gray-400">1-2 dias úteis, sem taxas</p>
                    </div>
                  </button>
                  
                  <button 
                    className={`w-full text-left p-3 rounded-md flex items-center space-x-3 ${selectedMethod === 'crypto' ? 'bg-green-900 border border-green-500' : 'bg-gray-700 hover:bg-gray-600'}`}
                    onClick={() => setSelectedMethod('crypto')}
                  >
                    <span className="text-2xl">₿</span>
                    <div>
                      <p className="font-bold">Criptomoedas</p>
                      <p className="text-xs text-gray-400">10-30 minutos, taxa variável</p>
                    </div>
                  </button>
                </div>
                
                <div className="mt-6 p-4 bg-gray-700 rounded-lg">
                  <h3 className="font-bold mb-2">Valores Sugeridos</h3>
                  <div className="grid grid-cols-3 gap-2">
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('50')}
                    >
                      R$ 50
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('100')}
                    >
                      R$ 100
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('200')}
                    >
                      R$ 200
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('500')}
                    >
                      R$ 500
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('1000')}
                    >
                      R$ 1000
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('2000')}
                    >
                      R$ 2000
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Right Column - Payment Form or QR Code */}
            <div className="md:col-span-2">
              {!showQRCode ? (
                <PaymentForm 
                  method={selectedMethod}
                  amount={amount}
                  onAmountChange={setAmount}
                  onSubmit={handleSubmit}
                />
              ) : (
                <div className="bg-gray-800 rounded-lg p-6 text-center">
                  <h3 className="text-xl font-bold mb-4">PIX QR Code</h3>
                  <div className="bg-white p-8 rounded-lg inline-block mb-4">
                    <div className="w-48 h-48 bg-gray-200 mx-auto flex items-center justify-center">
                      <div className="text-black text-6xl">QR</div>
                    </div>
                  </div>
                  <div className="mb-6">
                    <p className="text-gray-300 mb-2">Valor: <span className="font-bold">R$ {amount}</span></p>
                    <p className="text-gray-300 mb-4">Escaneie o QR Code acima com o aplicativo do seu banco ou copie a chave PIX abaixo:</p>
                    <div className="flex">
                      <input 
                        type="text" 
                        className="flex-1 bg-gray-700 rounded-l-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        value="00020126580014br.gov.bcb.pix0136a1e4d9f8-7c9b-4b8a-9c5d-944c53c8f40f5204000053039865802BR5925BingoBet Entretenimento6009Sao Paulo62070503***63041234"
                        readOnly
                      />
                      <button className="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-r-md transition-colors">
                        Copiar
                      </button>
                    </div>
                  </div>
                  <div className="bg-yellow-900 p-4 rounded-lg mb-6">
                    <p className="text-yellow-300 font-bold">Importante:</p>
                    <p className="text-gray-300 text-sm">Este QR Code é válido por 30 minutos. Após o pagamento, o valor será creditado automaticamente em sua conta.</p>
                  </div>
                  <button 
                    className="btn-secondary"
                    onClick={() => setShowQRCode(false)}
                  >
                    Voltar
                  </button>
                </div>
              )}
            </div>
          </div>
          
          {/* Deposit Information */}
          <div className="mt-12 bg-gray-800 rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Informações Importantes</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gray-700 p-4 rounded-lg">
                <h3 className="font-bold text-green-500 mb-2">Depósitos Instantâneos</h3>
                <p className="text-gray-300 text-sm">
                  Depósitos via PIX e cartão de crédito são processados instantaneamente. Você poderá jogar imediatamente após a confirmação do pagamento.
                </p>
              </div>
              
              <div className="bg-gray-700 p-4 rounded-lg">
                <h3 className="font-bold text-yellow-500 mb-2">Limites de Depósito</h3>
                <p className="text-gray-300 text-sm">
                  Valor mínimo: R$ 10<br />
                  Valor máximo: R$ 10.000 por transação<br />
                  Limite mensal: R$ 50.000
                </p>
              </div>
              
              <div className="bg-gray-700 p-4 rounded-lg">
                <h3 className="font-bold text-red-500 mb-2">Jogo Responsável</h3>
                <p className="text-gray-300 text-sm">
                  Estabeleça limites de depósito diários, semanais ou mensais para controlar seus gastos. Acesse as configurações da sua conta para definir seus limites.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
