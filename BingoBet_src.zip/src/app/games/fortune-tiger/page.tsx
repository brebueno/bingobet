import React, { useState } from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';

export default function FortuneTigerPage() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [balance, setBalance] = useState(1000);
  const [betAmount, setBetAmount] = useState(10);
  const [autoSpin, setAutoSpin] = useState(false);
  const [spinCount, setSpinCount] = useState(0);
  
  const handlePlay = () => {
    setIsPlaying(true);
  };
  
  const handleBetChange = (amount: number) => {
    setBetAmount(amount);
  };
  
  const handleSpin = () => {
    // Simulação de jogo
    setBalance(prev => prev - betAmount);
    setSpinCount(prev => prev + 1);
    
    // Simulação de resultado aleatório (25% de chance de ganhar)
    const win = Math.random() < 0.25;
    
    if (win) {
      const multiplier = [1.5, 2, 3, 5, 10][Math.floor(Math.random() * 5)];
      const winAmount = betAmount * multiplier;
      
      setTimeout(() => {
        setBalance(prev => prev + winAmount);
      }, 2000);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Fortune Tiger Game Page */}
      <section className="py-8 bg-gradient-to-b from-red-900 to-gray-900">
        <div className="container-main">
          <div className="flex flex-col md:flex-row items-start gap-8">
            {/* Game Area */}
            <div className="w-full md:w-3/4">
              <div className="bg-gray-800 rounded-lg overflow-hidden">
                <div className="bg-gradient-to-r from-red-800 to-yellow-700 p-4 flex justify-between items-center">
                  <div className="flex items-center">
                    <img 
                      src="https://via.placeholder.com/40" 
                      alt="PG Soft" 
                      className="h-8 w-8 mr-3 rounded-full bg-white p-1"
                    />
                    <h1 className="text-2xl font-bold text-white">Fortune Tiger</h1>
                  </div>
                  <div className="flex space-x-2">
                    <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                      </svg>
                    </button>
                    <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                      </svg>
                    </button>
                    <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="relative">
                  {!isPlaying ? (
                    <div className="relative">
                      <img 
                        src="https://via.placeholder.com/800x600/FF4500/FFFFFF?text=Fortune+Tiger" 
                        alt="Fortune Tiger" 
                        className="w-full"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-70">
                        <button 
                          className="btn-primary text-xl px-8 py-4"
                          onClick={handlePlay}
                        >
                          Jogar Agora
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="aspect-w-16 aspect-h-9 bg-black">
                      <div className="flex flex-col items-center justify-center h-full">
                        <div className="grid grid-cols-3 gap-2 mb-8">
                          <div className="bg-yellow-600 h-32 w-32 rounded-lg flex items-center justify-center">
                            <span className="text-6xl">🐯</span>
                          </div>
                          <div className="bg-yellow-600 h-32 w-32 rounded-lg flex items-center justify-center">
                            <span className="text-6xl">🐯</span>
                          </div>
                          <div className="bg-yellow-600 h-32 w-32 rounded-lg flex items-center justify-center">
                            <span className="text-6xl">🐯</span>
                          </div>
                        </div>
                        <button 
                          className="btn-primary text-xl px-8 py-4 mb-4"
                          onClick={handleSpin}
                        >
                          Girar
                        </button>
                        <div className="flex space-x-4">
                          <button 
                            className={`px-4 py-2 rounded-md ${autoSpin ? 'bg-green-600' : 'bg-gray-700'}`}
                            onClick={() => setAutoSpin(!autoSpin)}
                          >
                            Auto Spin
                          </button>
                          <div className="bg-gray-700 px-4 py-2 rounded-md">
                            Giros: {spinCount}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="bg-gray-900 p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-gray-400 text-sm">Saldo</p>
                      <p className="text-2xl font-bold text-white">R$ {balance.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Aposta</p>
                      <div className="flex items-center space-x-2">
                        <button 
                          className="bg-gray-700 hover:bg-gray-600 text-white p-1 rounded-md"
                          onClick={() => handleBetChange(Math.max(1, betAmount - 1))}
                        >
                          -
                        </button>
                        <p className="text-xl font-bold text-white">R$ {betAmount.toFixed(2)}</p>
                        <button 
                          className="bg-gray-700 hover:bg-gray-600 text-white p-1 rounded-md"
                          onClick={() => handleBetChange(betAmount + 1)}
                        >
                          +
                        </button>
                      </div>
                    </div>
                    <div>
                      <p className="text-gray-400 text-sm">Ganho Potencial</p>
                      <p className="text-2xl font-bold text-green-500">R$ {(betAmount * 10).toFixed(2)}</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 bg-gray-800 rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Sobre Fortune Tiger</h2>
                <p className="text-gray-300 mb-4">
                  Fortune Tiger é um dos jogos mais populares da PG Soft, com um tema asiático inspirado no tigre, símbolo de força e prosperidade. Este jogo de caça-níquel apresenta um layout de 3x3 com gráficos vibrantes e uma jogabilidade emocionante.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="bg-gray-700 p-3 rounded-lg">
                    <h3 className="font-bold text-yellow-500 mb-1">RTP</h3>
                    <p className="text-white">96.8%</p>
                  </div>
                  <div className="bg-gray-700 p-3 rounded-lg">
                    <h3 className="font-bold text-yellow-500 mb-1">Volatilidade</h3>
                    <p className="text-white">Alta</p>
                  </div>
                  <div className="bg-gray-700 p-3 rounded-lg">
                    <h3 className="font-bold text-yellow-500 mb-1">Ganho Máximo</h3>
                    <p className="text-white">1000x</p>
                  </div>
                </div>
                <h3 className="font-bold text-lg mb-2">Recursos Especiais</h3>
                <ul className="list-disc pl-5 text-gray-300 space-y-1">
                  <li>Giros Grátis</li>
                  <li>Multiplicadores</li>
                  <li>Símbolos Wild</li>
                  <li>Modo Turbo</li>
                  <li>Recurso de Compra de Bônus</li>
                </ul>
              </div>
            </div>
            
            {/* Sidebar */}
            <div className="w-full md:w-1/4 space-y-6">
              <div className="bg-gray-800 rounded-lg p-4">
                <h2 className="text-lg font-bold mb-3">Jogos Semelhantes</h2>
                <div className="space-y-3">
                  <a href="#" className="block bg-gray-700 rounded-lg overflow-hidden hover:ring-2 hover:ring-yellow-500 transition-all">
                    <img 
                      src="https://via.placeholder.com/300x200/FF8C00/FFFFFF?text=Fortune+Rabbit" 
                      alt="Fortune Rabbit" 
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2">
                      <p className="font-bold">Fortune Rabbit</p>
                      <p className="text-xs text-gray-400">PG Soft</p>
                    </div>
                  </a>
                  
                  <a href="#" className="block bg-gray-700 rounded-lg overflow-hidden hover:ring-2 hover:ring-yellow-500 transition-all">
                    <img 
                      src="https://via.placeholder.com/300x200/FF4500/FFFFFF?text=Fortune+Ox" 
                      alt="Fortune Ox" 
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2">
                      <p className="font-bold">Fortune Ox</p>
                      <p className="text-xs text-gray-400">PG Soft</p>
                    </div>
                  </a>
                  
                  <a href="#" className="block bg-gray-700 rounded-lg overflow-hidden hover:ring-2 hover:ring-yellow-500 transition-all">
                    <img 
                      src="https://via.placeholder.com/300x200/9932CC/FFFFFF?text=Sweet+Bonanza" 
                      alt="Sweet Bonanza" 
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2">
                      <p className="font-bold">Sweet Bonanza</p>
                      <p className="text-xs text-gray-400">Pragmatic Play</p>
                    </div>
                  </a>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-yellow-700 to-red-700 rounded-lg p-4">
                <h2 className="text-lg font-bold mb-3">Bônus Especial</h2>
                <p className="text-white mb-3">Ganhe 100 giros grátis no Fortune Tiger!</p>
                <button className="bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-2 px-4 rounded-md w-full">
                  Resgatar Bônus
                </button>
              </div>
              
              <div className="bg-gray-800 rounded-lg p-4">
                <h2 className="text-lg font-bold mb-3">Torneio Fortune Tiger</h2>
                <div className="bg-gray-700 p-3 rounded-lg mb-3">
                  <div className="flex justify-between items-center mb-2">
                    <p className="font-bold">Prêmio Total</p>
                    <p className="text-yellow-500 font-bold">R$ 50.000</p>
                  </div>
                  <div className="flex justify-between items-center mb-2">
                    <p className="text-sm">Participantes</p>
                    <p className="text-sm">1.245</p>
                  </div>
                  <div className="flex justify-between items-center">
                    <p className="text-sm">Termina em</p>
                    <p className="text-sm">23:45:12</p>
                  </div>
                </div>
                <button className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-md w-full">
                  Participar
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
