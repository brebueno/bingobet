import React from 'react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import Link from 'next/link';

export default function GamesPage() {
  const featuredGames = [
    {
      id: 'fortune-tiger',
      name: 'Fortune Tiger',
      provider: 'PG Soft',
      image: 'https://via.placeholder.com/400x300/FF4500/FFFFFF?text=Fortune+Tiger',
      category: 'slots',
      isHot: true,
      isNew: false
    },
    {
      id: 'fortune-rabbit',
      name: 'Fortune Rabbit',
      provider: 'PG Soft',
      image: 'https://via.placeholder.com/400x300/FF8C00/FFFFFF?text=Fortune+Rabbit',
      category: 'slots',
      isHot: true,
      isNew: true
    },
    {
      id: 'aviator',
      name: 'Aviator',
      provider: 'Spribe',
      image: 'https://via.placeholder.com/400x300/0047AB/FFFFFF?text=Aviator',
      category: 'crash',
      isHot: true,
      isNew: false
    },
    {
      id: 'sweet-bonanza',
      name: 'Sweet Bonanza',
      provider: 'Pragmatic Play',
      image: 'https://via.placeholder.com/400x300/9932CC/FFFFFF?text=Sweet+Bonanza',
      category: 'slots',
      isHot: true,
      isNew: false
    }
  ];
  
  const allGames = [
    ...featuredGames,
    {
      id: 'fortune-ox',
      name: 'Fortune Ox',
      provider: 'PG Soft',
      image: 'https://via.placeholder.com/400x300/8B4513/FFFFFF?text=Fortune+Ox',
      category: 'slots',
      isHot: false,
      isNew: false
    },
    {
      id: 'gates-of-olympus',
      name: 'Gates of Olympus',
      provider: 'Pragmatic Play',
      image: 'https://via.placeholder.com/400x300/4169E1/FFFFFF?text=Gates+of+Olympus',
      category: 'slots',
      isHot: true,
      isNew: false
    },
    {
      id: 'spaceman',
      name: 'Spaceman',
      provider: 'Pragmatic Play',
      image: 'https://via.placeholder.com/400x300/483D8B/FFFFFF?text=Spaceman',
      category: 'crash',
      isHot: false,
      isNew: false
    },
    {
      id: 'mines',
      name: 'Mines',
      provider: 'Spribe',
      image: 'https://via.placeholder.com/400x300/696969/FFFFFF?text=Mines',
      category: 'instant',
      isHot: false,
      isNew: true
    },
    {
      id: 'fruit-party',
      name: 'Fruit Party',
      provider: 'Pragmatic Play',
      image: 'https://via.placeholder.com/400x300/32CD32/FFFFFF?text=Fruit+Party',
      category: 'slots',
      isHot: false,
      isNew: false
    },
    {
      id: 'plinko',
      name: 'Plinko',
      provider: 'Spribe',
      image: 'https://via.placeholder.com/400x300/FF69B4/FFFFFF?text=Plinko',
      category: 'instant',
      isHot: true,
      isNew: false
    },
    {
      id: 'dragon-tiger',
      name: 'Dragon Tiger',
      provider: 'Evolution Gaming',
      image: 'https://via.placeholder.com/400x300/B22222/FFFFFF?text=Dragon+Tiger',
      category: 'live',
      isHot: false,
      isNew: false
    },
    {
      id: 'crazy-time',
      name: 'Crazy Time',
      provider: 'Evolution Gaming',
      image: 'https://via.placeholder.com/400x300/FF00FF/FFFFFF?text=Crazy+Time',
      category: 'live',
      isHot: true,
      isNew: false
    }
  ];
  
  const categories = [
    { id: 'all', name: 'Todos' },
    { id: 'slots', name: 'Slots' },
    { id: 'crash', name: 'Crash Games' },
    { id: 'instant', name: 'Jogos Instantâneos' },
    { id: 'live', name: 'Cassino ao Vivo' },
    { id: 'brazilian', name: 'Jogos Brasileiros' }
  ];
  
  const providers = [
    { id: 'pgsoft', name: 'PG Soft', count: 136 },
    { id: 'evolution', name: 'Evolution Gaming', count: 209 },
    { id: 'spribe', name: 'Spribe', count: 8 },
    { id: 'pragmatic', name: 'Pragmatic Play', count: 240 },
    { id: 'playson', name: 'Playson', count: 27 },
    { id: 'nsoft', name: 'Nsoft', count: 48 }
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Hero Section */}
      <section className="py-8 bg-gradient-to-r from-gray-900 to-gray-800">
        <div className="container-main">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div>
              <h1 className="text-4xl font-bold mb-2">
                Jogos <span className="text-green-500">Populares</span>
              </h1>
              <p className="text-gray-300 mb-4 md:mb-0">
                Descubra os melhores jogos de cassino e apostas online
              </p>
            </div>
            <div className="flex space-x-4">
              <div className="relative">
                <input 
                  type="text" 
                  placeholder="Buscar jogos..." 
                  className="bg-gray-800 text-white px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500 w-64"
                />
                <button className="absolute right-2 top-2 text-gray-400">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
                  </svg>
                </button>
              </div>
              <button className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-md">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Games */}
      <section className="py-8 bg-gray-900">
        <div className="container-main">
          <h2 className="text-2xl font-bold mb-6">Jogos em Destaque</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredGames.map(game => (
              <Link href={`/games/${game.id}`} key={game.id}>
                <div className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-green-500 transition-all hover:-translate-y-1 cursor-pointer">
                  <div className="relative">
                    <img 
                      src={game.image} 
                      alt={game.name} 
                      className="w-full h-48 object-cover"
                    />
                    <div className="absolute top-2 left-2 flex space-x-2">
                      {game.isHot && (
                        <div className="bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                          HOT
                        </div>
                      )}
                      {game.isNew && (
                        <div className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                          NOVO
                        </div>
                      )}
                    </div>
                    <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                      <h3 className="text-xl font-bold">{game.name}</h3>
                      <p className="text-sm text-gray-300">{game.provider}</p>
                    </div>
                  </div>
                  <div className="p-4 flex justify-between items-center">
                    <div className="bg-gray-700 px-2 py-1 rounded-md text-xs">
                      {game.category === 'slots' && 'Slots'}
                      {game.category === 'crash' && 'Crash Game'}
                      {game.category === 'instant' && 'Instantâneo'}
                      {game.category === 'live' && 'Ao Vivo'}
                    </div>
                    <button className="btn-primary text-sm py-1 px-3">
                      Jogar
                    </button>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Game Categories */}
      <section className="py-8 bg-gray-800">
        <div className="container-main">
          <div className="flex flex-wrap gap-2 mb-8">
            {categories.map(category => (
              <button 
                key={category.id}
                className={`px-4 py-2 rounded-md ${category.id === 'all' ? 'bg-green-600 text-white' : 'bg-gray-700 text-white hover:bg-gray-600'}`}
              >
                {category.name}
              </button>
            ))}
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {allGames.map(game => (
              <Link href={`/games/${game.id}`} key={game.id}>
                <div className="bg-gray-700 rounded-lg overflow-hidden hover:ring-2 hover:ring-green-500 transition-all hover:-translate-y-1 cursor-pointer">
                  <div className="relative">
                    <img 
                      src={game.image} 
                      alt={game.name} 
                      className="w-full h-40 object-cover"
                    />
                    <div className="absolute top-2 left-2 flex space-x-2">
                      {game.isHot && (
                        <div className="bg-red-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                          HOT
                        </div>
                      )}
                      {game.isNew && (
                        <div className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                          NOVO
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="p-3">
                    <h3 className="font-bold truncate">{game.name}</h3>
                    <p className="text-xs text-gray-400 mb-2">{game.provider}</p>
                    <button className="w-full bg-green-600 hover:bg-green-700 text-white text-sm font-bold py-1 px-3 rounded-md transition-colors">
                      Jogar Agora
                    </button>
                  </div>
                </div>
              </Link>
            ))}
          </div>
          
          <div className="mt-8 text-center">
            <button className="btn-secondary px-6 py-2">
              Carregar Mais Jogos
            </button>
          </div>
        </div>
      </section>

      {/* Game Providers */}
      <section className="py-8 bg-gray-900">
        <div className="container-main">
          <h2 className="text-2xl font-bold mb-6">Provedores de Jogos</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {providers.map(provider => (
              <div key={provider.id} className="bg-gray-800 rounded-lg p-4 text-center hover:bg-gray-700 transition-colors cursor-pointer">
                <div className="h-16 flex items-center justify-center mb-2">
                  <div className="text-xl font-bold">{provider.name}</div>
                </div>
                <p className="text-sm text-gray-400">{provider.count} jogos</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Brazilian Games */}
      <section className="py-8 bg-gradient-to-r from-green-900 to-yellow-900">
        <div className="container-main">
          <div className="flex flex-col md:flex-row justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold mb-2">Jogos Brasileiros</h2>
              <p className="text-gray-300">Experimente os jogos tradicionais do Brasil</p>
            </div>
            <button className="btn-primary mt-4 md:mt-0">Ver Todos</button>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-yellow-500 transition-all hover:-translate-y-1 cursor-pointer">
              <div className="relative">
                <img 
                  src="https://via.placeholder.com/400x300/006400/FFFFFF?text=Truco" 
                  alt="Truco" 
                  className="w-full h-48 object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                  <h3 className="text-xl font-bold">Truco</h3>
                  <p className="text-sm text-gray-300">Jogo de Cartas Brasileiro</p>
                </div>
              </div>
              <div className="p-4 flex justify-between items-center">
                <div className="bg-green-900 px-2 py-1 rounded-md text-xs">
                  Cartas
                </div>
                <button className="btn-primary text-sm py-1 px-3">
                  Jogar
                </button>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-yellow-500 transition-all hover:-translate-y-1 cursor-pointer">
              <div className="relative">
                <img 
                  src="https://via.placeholder.com/400x300/8B4513/FFFFFF?text=Canastra" 
                  alt="Canastra" 
                  className="w-full h-48 object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                  <h3 className="text-xl font-bold">Canastra</h3>
                  <p className="text-sm text-gray-300">Jogo de Cartas Brasileiro</p>
                </div>
              </div>
              <div className="p-4 flex justify-between items-center">
                <div className="bg-green-900 px-2 py-1 rounded-md text-xs">
                  Cartas
                </div>
                <button className="btn-primary text-sm py-1 px-3">
                  Jogar
                </button>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-yellow-500 transition-all hover:-translate-y-1 cursor-pointer">
              <div className="relative">
                <img 
                  src="https://via.placeholder.com/400x300/000000/FFFFFF?text=Dominó" 
                  alt="Dominó" 
                  className="w-full h-48 object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                  <h3 className="text-xl font-bold">Dominó</h3>
                  <p className="text-sm text-gray-300">Jogo de Peças</p>
                </div>
              </div>
              <div className="p-4 flex justify-between items-center">
                <div className="bg-green-900 px-2 py-1 rounded-md text-xs">
                  Tabuleiro
                </div>
                <button className="btn-primary text-sm py-1 px-3">
                  Jogar
                </button>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-lg overflow-hidden hover:ring-2 hover:ring-yellow-500 transition-all hover:-translate-y-1 cursor-pointer">
              <div className="relative">
                <img 
                  src="https://via.placeholder.com/400x300/4B0082/FFFFFF?text=Caxeta" 
                  alt="Caxeta" 
                  className="w-full h-48 object-cover"
                />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                  <h3 className="text-xl font-bold">Caxeta</h3>
                  <p className="text-sm text-gray-300">Jogo de Cartas Brasileiro</p>
                </div>
              </div>
              <div className="p-4 flex justify-between items-center">
                <div className="bg-green-900 px-2 py-1 rounded-md text-xs">
                  Cartas
                </div>
                <button className="btn-primary text-sm py-1 px-3">
                  Jogar
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
