import React, { useState } from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';

export default function AviatorPage() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [balance, setBalance] = useState(1000);
  const [betAmount, setBetAmount] = useState(10);
  const [multiplier, setMultiplier] = useState(1.00);
  const [isFlying, setIsFlying] = useState(false);
  const [hasCrashed, setHasCrashed] = useState(false);
  const [autoCashout, setAutoCashout] = useState(false);
  const [autoCashoutValue, setAutoCashoutValue] = useState(2.00);
  
  const handlePlay = () => {
    setIsPlaying(true);
  };
  
  const handleBetChange = (amount: number) => {
    setBetAmount(amount);
  };
  
  const handleStart = () => {
    // Reset game state
    setMultiplier(1.00);
    setIsFlying(true);
    setHasCrashed(false);
    setBalance(prev => prev - betAmount);
    
    // Start the multiplier increase
    const interval = setInterval(() => {
      setMultiplier(prev => {
        // Random crash point between 1.00 and 10.00
        const crashPoint = 1 + Math.random() * 9;
        
        if (prev >= crashPoint) {
          clearInterval(interval);
          setIsFlying(false);
          setHasCrashed(true);
          return prev;
        }
        
        // Check for auto cashout
        if (autoCashout && prev >= autoCashoutValue) {
          clearInterval(interval);
          setIsFlying(false);
          setBalance(b => b + (betAmount * prev));
          return prev;
        }
        
        // Increase multiplier
        return parseFloat((prev + 0.01).toFixed(2));
      });
    }, 100);
  };
  
  const handleCashout = () => {
    if (isFlying) {
      setIsFlying(false);
      setBalance(prev => prev + (betAmount * multiplier));
    }
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Aviator Game Page */}
      <section className="py-8 bg-gradient-to-b from-blue-900 to-gray-900">
        <div className="container-main">
          <div className="flex flex-col md:flex-row items-start gap-8">
            {/* Game Area */}
            <div className="w-full md:w-3/4">
              <div className="bg-gray-800 rounded-lg overflow-hidden">
                <div className="bg-gradient-to-r from-blue-800 to-purple-700 p-4 flex justify-between items-center">
                  <div className="flex items-center">
                    <img 
                      src="https://via.placeholder.com/40" 
                      alt="Spribe" 
                      className="h-8 w-8 mr-3 rounded-full bg-white p-1"
                    />
                    <h1 className="text-2xl font-bold text-white">Aviator</h1>
                  </div>
                  <div className="flex space-x-2">
                    <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
                      </svg>
                    </button>
                    <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                      </svg>
                    </button>
                    <button className="bg-gray-700 hover:bg-gray-600 text-white p-2 rounded-full">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                      </svg>
                    </button>
                  </div>
                </div>
                
                <div className="relative">
                  {!isPlaying ? (
                    <div className="relative">
                      <img 
                        src="https://via.placeholder.com/800x600/0047AB/FFFFFF?text=Aviator" 
                        alt="Aviator" 
                        className="w-full"
                      />
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-70">
                        <button 
                          className="btn-primary text-xl px-8 py-4"
                          onClick={handlePlay}
                        >
                          Jogar Agora
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="aspect-w-16 aspect-h-9 bg-gradient-to-b from-blue-900 to-black p-4">
                      <div className="flex flex-col items-center justify-center h-full">
                        <div className="text-6xl font-bold mb-8 text-white">
                          {multiplier.toFixed(2)}x
                        </div>
                        
                        <div className="relative w-full h-64 mb-8">
                          <div className="absolute bottom-0 left-0 w-full h-1 bg-gray-700"></div>
                          
                          {isFlying && (
                            <div 
                              className="absolute bottom-0 left-0"
                              style={{ 
                                transform: `translate(${Math.min(100, multiplier * 10)}%, ${-Math.min(100, multiplier * 10)}px)`,
                                transition: 'transform 0.1s linear'
                              }}
                            >
                              <div className="text-4xl">✈️</div>
                            </div>
                          )}
                          
                          {hasCrashed && (
                            <div className="absolute inset-0 flex items-center justify-center">
                              <div className="text-4xl text-red-500 font-bold animate-pulse">CRASH!</div>
                            </div>
                          )}
                        </div>
                        
                        <div className="flex space-x-4">
                          <button 
                            className="btn-primary text-xl px-8 py-4"
                            onClick={handleStart}
                            disabled={isFlying}
                          >
                            Iniciar
                          </button>
                          
                          <button 
                            className={`text-xl px-8 py-4 rounded-md ${isFlying ? 'bg-green-600 hover:bg-green-700 text-white' : 'bg-gray-700 text-gray-400 cursor-not-allowed'}`}
                            onClick={handleCashout}
                            disabled={!isFlying}
                          >
                            Sacar
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="bg-gray-900 p-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <p className="text-gray-400 text-sm">Saldo</p>
                      <p className="text-2xl font-bold text-white">R$ {balance.toFixed(2)}</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-400 text-sm">Aposta</p>
                      <div className="flex items-center space-x-2">
                        <button 
                          className="bg-gray-700 hover:bg-gray-600 text-white p-1 rounded-md"
                          onClick={() => handleBetChange(Math.max(1, betAmount - 1))}
                        >
                          -
                        </button>
                        <p className="text-xl font-bold text-white">R$ {betAmount.toFixed(2)}</p>
                        <button 
                          className="bg-gray-700 hover:bg-gray-600 text-white p-1 rounded-md"
                          onClick={() => handleBetChange(betAmount + 1)}
                        >
                          +
                        </button>
                      </div>
                    </div>
                    
                    <div>
                      <p className="text-gray-400 text-sm">Auto Cashout</p>
                      <div className="flex items-center space-x-2">
                        <input 
                          type="checkbox" 
                          checked={autoCashout}
                          onChange={() => setAutoCashout(!autoCashout)}
                          className="mr-2"
                        />
                        <input 
                          type="number" 
                          value={autoCashoutValue}
                          onChange={(e) => setAutoCashoutValue(parseFloat(e.target.value))}
                          min="1.01"
                          step="0.01"
                          className="bg-gray-700 text-white p-1 rounded-md w-20 text-center"
                        />
                        <span className="text-white">x</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 bg-gray-800 rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Sobre Aviator</h2>
                <p className="text-gray-300 mb-4">
                  Aviator é um jogo inovador da Spribe que revolucionou o mercado de jogos de cassino. Com uma mecânica simples e viciante, o jogo apresenta um avião que decola e seu multiplicador aumenta até que ele voe para longe (crash). Os jogadores devem sacar seus ganhos antes que o avião desapareça para garantir seus lucros.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="bg-gray-700 p-3 rounded-lg">
                    <h3 className="font-bold text-blue-500 mb-1">RTP</h3>
                    <p className="text-white">97.0%</p>
                  </div>
                  <div className="bg-gray-700 p-3 rounded-lg">
                    <h3 className="font-bold text-blue-500 mb-1">Volatilidade</h3>
                    <p className="text-white">Média</p>
                  </div>
                  <div className="bg-gray-700 p-3 rounded-lg">
                    <h3 className="font-bold text-blue-500 mb-1">Ganho Máximo</h3>
                    <p className="text-white">Ilimitado (teoricamente)</p>
                  </div>
                </div>
                <h3 className="font-bold text-lg mb-2">Recursos Especiais</h3>
                <ul className="list-disc pl-5 text-gray-300 space-y-1">
                  <li>Multiplicador crescente em tempo real</li>
                  <li>Auto Cashout configurável</li>
                  <li>Apostas múltiplas simultâneas</li>
                  <li>Chat ao vivo com outros jogadores</li>
                  <li>Histórico de rodadas anteriores</li>
                </ul>
              </div>
            </div>
            
            {/* Sidebar */}
            <div className="w-full md:w-1/4 space-y-6">
              <div className="bg-gray-800 rounded-lg p-4">
                <h2 className="text-lg font-bold mb-3">Jogos Semelhantes</h2>
                <div className="space-y-3">
                  <a href="/games/fortune-tiger" className="block bg-gray-700 rounded-lg overflow-hidden hover:ring-2 hover:ring-blue-500 transition-all">
                    <img 
                      src="https://via.placeholder.com/300x200/FF4500/FFFFFF?text=Fortune+Tiger" 
                      alt="Fortune Tiger" 
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2">
                      <p className="font-bold">Fortune Tiger</p>
                      <p className="text-xs text-gray-400">PG Soft</p>
                    </div>
                  </a>
                  
                  <a href="/games/fortune-rabbit" className="block bg-gray-700 rounded-lg overflow-hidden hover:ring-2 hover:ring-blue-500 transition-all">
                    <img 
                      src="https://via.placeholder.com/300x200/FF8C00/FFFFFF?text=Fortune+Rabbit" 
                      alt="Fortune Rabbit" 
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2">
                      <p className="font-bold">Fortune Rabbit</p>
                      <p className="text-xs text-gray-400">PG Soft</p>
                    </div>
                  </a>
                  
                  <a href="#" className="block bg-gray-700 rounded-lg overflow-hidden hover:ring-2 hover:ring-blue-500 transition-all">
                    <img 
                      src="https://via.placeholder.com/300x200/9932CC/FFFFFF?text=Spaceman" 
                      alt="Spaceman" 
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2">
                      <p className="font-bold">Spaceman</p>
                      <p className="text-xs text-gray-400">Pragmatic Play</p>
                    </div>
                  </a>
                </div>
              </div>
              
              <div className="bg-gradient-to-r from-blue-700 to-purple-700 rounded-lg p-4">
                <h2 className="text-lg font-bold mb-3">Bônus Especial</h2>
                <p className="text-white mb-3">Ganhe R$ 50 para apostar no Aviator!</p>
                <button className="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-md w-full">
                  Resgatar Bônus
                </button>
              </div>
              
              <div className="bg-gray-800 rounded-lg p-4">
                <h2 className="text-lg font-bold mb-3">Estatísticas Recentes</h2>
                <div className="bg-gray-700 p-3 rounded-lg mb-3">
                  <h3 className="font-bold mb-2">Últimos Multiplicadores</h3>
                  <div className="flex flex-wrap gap-2">
                    <div className="bg-red-900 text-white px-2 py-1 rounded-md text-sm">1.24x</div>
                    <div className="bg-green-900 text-white px-2 py-1 rounded-md text-sm">3.87x</div>
                    <div className="bg-red-900 text-white px-2 py-1 rounded-md text-sm">1.05x</div>
                    <div className="bg-green-900 text-white px-2 py-1 rounded-md text-sm">2.56x</div>
                    <div className="bg-green-900 text-white px-2 py-1 rounded-md text-sm">5.12x</div>
                    <div className="bg-red-900 text-white px-2 py-1 rounded-md text-sm">1.78x</div>
                    <div className="bg-green-900 text-white px-2 py-1 rounded-md text-sm">8.34x</div>
                    <div className="bg-red-900 text-white px-2 py-1 rounded-md text-sm">1.12x</div>
                  </div>
                </div>
                
                <div className="bg-gray-700 p-3 rounded-lg mb-3">
                  <h3 className="font-bold mb-2">Estatísticas</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Maior multiplicador hoje:</span>
                      <span className="text-sm font-bold text-green-500">127.54x</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Jogadores online:</span>
                      <span className="text-sm font-bold">1,245</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm">Total de apostas hoje:</span>
                      <span className="text-sm font-bold">R$ 1,567,890</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
