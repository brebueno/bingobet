import React, { useState } from 'react';
import Header from '../components/layout/Header';
import Footer from '../components/layout/Footer';
import AchievementCard from '../components/ui/AchievementCard';
import UserProfile from '../components/ui/UserProfile';

export default function AchievementsPage() {
  const [filter, setFilter] = useState('all');
  
  const achievements = [
    {
      id: 'first-win',
      title: 'Primeira Vitória',
      description: 'Ganhe sua primeira rodada em qualquer jogo da plataforma.',
      icon: '🏆',
      progress: 1,
      maxProgress: 1,
      reward: '50 pontos + R$ 5,00 em bônus',
      isCompleted: true,
      category: 'beginner'
    },
    {
      id: 'fortune-tiger-master',
      title: 'Mestre do Fortune Tiger',
      description: 'Ganhe 50 rodadas no jogo Fortune Tiger.',
      icon: '🐯',
      progress: 32,
      maxProgress: 50,
      reward: '200 pontos + 10 giros grátis',
      isCompleted: false,
      category: 'slots',
      isNew: true
    },
    {
      id: 'bingo-lover',
      title: 'Amante do Bingo',
      description: 'Complete 20 cartelas de bingo.',
      icon: '🎯',
      progress: 20,
      maxProgress: 20,
      reward: '150 pontos + 1 cartela grátis',
      isCompleted: true,
      category: 'bingo'
    },
    {
      id: 'deposit-king',
      title: 'Rei dos Depósitos',
      description: 'Faça 5 depósitos na plataforma.',
      icon: '💰',
      progress: 3,
      maxProgress: 5,
      reward: '100 pontos + 50% de bônus no próximo depósito',
      isCompleted: false,
      category: 'financial'
    },
    {
      id: 'social-butterfly',
      title: 'Borboleta Social',
      description: 'Envie 50 mensagens no chat durante jogos.',
      icon: '💬',
      progress: 23,
      maxProgress: 50,
      reward: '75 pontos + emoji exclusivo',
      isCompleted: false,
      category: 'social'
    },
    {
      id: 'aviator-pro',
      title: 'Aviator Profissional',
      description: 'Consiga um multiplicador de 10x ou mais no Aviator.',
      icon: '✈️',
      progress: 0,
      maxProgress: 1,
      reward: '300 pontos + R$ 10,00 em bônus',
      isCompleted: false,
      category: 'crash'
    },
    {
      id: 'tournament-winner',
      title: 'Campeão de Torneio',
      description: 'Fique entre os 3 primeiros em qualquer torneio.',
      icon: '🏅',
      progress: 0,
      maxProgress: 1,
      reward: '500 pontos + entrada grátis no próximo torneio',
      isCompleted: false,
      category: 'tournament'
    },
    {
      id: 'loyal-player',
      title: 'Jogador Fiel',
      description: 'Faça login na plataforma por 30 dias consecutivos.',
      icon: '📅',
      progress: 14,
      maxProgress: 30,
      reward: '250 pontos + item exclusivo de perfil',
      isCompleted: false,
      category: 'loyalty'
    }
  ];
  
  const filteredAchievements = filter === 'all' 
    ? achievements 
    : filter === 'completed' 
      ? achievements.filter(a => a.isCompleted) 
      : filter === 'in-progress' 
        ? achievements.filter(a => !a.isCompleted) 
        : achievements.filter(a => a.category === filter);
  
  const categories = [
    { id: 'all', name: 'Todos' },
    { id: 'completed', name: 'Concluídos' },
    { id: 'in-progress', name: 'Em Progresso' },
    { id: 'beginner', name: 'Iniciante' },
    { id: 'slots', name: 'Slots' },
    { id: 'bingo', name: 'Bingo' },
    { id: 'crash', name: 'Crash Games' },
    { id: 'tournament', name: 'Torneios' },
    { id: 'financial', name: 'Financeiro' },
    { id: 'loyalty', name: 'Fidelidade' },
    { id: 'social', name: 'Social' }
  ];
  
  const stats = {
    totalAchievements: achievements.length,
    completedAchievements: achievements.filter(a => a.isCompleted).length,
    totalPoints: 350,
    level: 5
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="pt-20 pb-12 bg-gray-900">
        <div className="container-main">
          {/* Page Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">
                Conquistas e <span className="text-yellow-500">Recompensas</span>
              </h1>
              <p className="text-gray-400">
                Complete desafios, ganhe pontos e desbloqueie recompensas exclusivas
              </p>
            </div>
            
            <div className="mt-4 md:mt-0">
              <UserProfile 
                username="JogadorVIP"
                balance={1250.75}
                level={5}
                avatarUrl="https://via.placeholder.com/40"
              />
            </div>
          </div>
          
          {/* Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="bg-gray-800 rounded-lg p-4">
              <p className="text-sm text-gray-400 mb-1">Nível</p>
              <div className="flex items-center">
                <div className="bg-yellow-500 text-black h-10 w-10 rounded-full flex items-center justify-center font-bold text-lg mr-3">
                  {stats.level}
                </div>
                <div>
                  <p className="font-bold text-xl">Aventureiro</p>
                  <div className="w-full bg-gray-700 h-2 rounded-full overflow-hidden mt-1">
                    <div className="bg-yellow-500 h-full" style={{ width: '65%' }}></div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4">
              <p className="text-sm text-gray-400 mb-1">Pontos</p>
              <p className="font-bold text-2xl text-yellow-500">{stats.totalPoints}</p>
              <p className="text-xs text-gray-400 mt-1">+75 pontos nos últimos 7 dias</p>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4">
              <p className="text-sm text-gray-400 mb-1">Conquistas Concluídas</p>
              <p className="font-bold text-2xl">{stats.completedAchievements} / {stats.totalAchievements}</p>
              <p className="text-xs text-gray-400 mt-1">{Math.round((stats.completedAchievements / stats.totalAchievements) * 100)}% concluído</p>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4">
              <p className="text-sm text-gray-400 mb-1">Próxima Recompensa</p>
              <p className="font-bold text-lg">50% de Bônus</p>
              <button className="mt-1 bg-green-600 hover:bg-green-700 text-white text-sm py-1 px-3 rounded-md">
                Resgatar
              </button>
            </div>
          </div>
          
          {/* Filters */}
          <div className="mb-6 overflow-x-auto">
            <div className="flex space-x-2 pb-2">
              {categories.map(category => (
                <button 
                  key={category.id}
                  className={`px-4 py-2 rounded-md whitespace-nowrap ${
                    filter === category.id 
                      ? 'bg-yellow-500 text-black font-bold' 
                      : 'bg-gray-800 text-white hover:bg-gray-700'
                  }`}
                  onClick={() => setFilter(category.id)}
                >
                  {category.name}
                </button>
              ))}
            </div>
          </div>
          
          {/* Achievements List */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredAchievements.map(achievement => (
              <AchievementCard 
                key={achievement.id}
                id={achievement.id}
                title={achievement.title}
                description={achievement.description}
                icon={achievement.icon}
                progress={achievement.progress}
                maxProgress={achievement.maxProgress}
                reward={achievement.reward}
                isCompleted={achievement.isCompleted}
                isNew={achievement.isNew}
              />
            ))}
          </div>
          
          {/* No Results */}
          {filteredAchievements.length === 0 && (
            <div className="bg-gray-800 rounded-lg p-8 text-center">
              <p className="text-xl font-bold mb-2">Nenhuma conquista encontrada</p>
              <p className="text-gray-400">Tente selecionar outra categoria ou voltar para todas as conquistas</p>
              <button 
                className="mt-4 bg-yellow-500 hover:bg-yellow-600 text-black font-bold py-2 px-6 rounded-md"
                onClick={() => setFilter('all')}
              >
                Ver Todas as Conquistas
              </button>
            </div>
          )}
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
