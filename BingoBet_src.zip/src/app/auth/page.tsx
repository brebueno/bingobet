import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';

export default function AuthPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      <div className="py-12 bg-gray-900">
        <div className="container-main max-w-md mx-auto">
          <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
            <div className="p-6">
              <div className="flex justify-center mb-6">
                <h1 className="text-2xl font-bold text-white">
                  <span className="text-green-500">Bingo</span>
                  <span className="text-yellow-500">Bet</span>
                </h1>
              </div>
              
              {/* Tabs */}
              <div className="flex mb-6">
                <button className="flex-1 py-2 border-b-2 border-green-500 text-white font-bold">
                  Entrar
                </button>
                <button className="flex-1 py-2 border-b-2 border-gray-700 text-gray-400 hover:text-white">
                  Cadastrar
                </button>
              </div>
              
              {/* Login Form */}
              <form>
                <div className="mb-4">
                  <label htmlFor="email" className="block text-gray-300 mb-2">Email</label>
                  <input 
                    type="email" 
                    id="email" 
                    className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="seu@email.com"
                  />
                </div>
                
                <div className="mb-6">
                  <label htmlFor="password" className="block text-gray-300 mb-2">Senha</label>
                  <input 
                    type="password" 
                    id="password" 
                    className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="********"
                  />
                  <div className="mt-1 text-right">
                    <a href="#" className="text-sm text-green-500 hover:text-green-400">Esqueceu a senha?</a>
                  </div>
                </div>
                
                <button 
                  type="submit" 
                  className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3 rounded-md transition-colors"
                >
                  Entrar
                </button>
              </form>
              
              <div className="mt-6 text-center">
                <p className="text-gray-400">Ou entre com</p>
                <div className="flex justify-center space-x-4 mt-4">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white font-bold px-4 py-2 rounded-md transition-colors">
                    Facebook
                  </button>
                  <button className="bg-white hover:bg-gray-200 text-gray-900 font-bold px-4 py-2 rounded-md transition-colors">
                    Google
                  </button>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-900 p-4 text-center">
              <p className="text-gray-400">
                Não tem uma conta? <a href="#" className="text-green-500 hover:text-green-400 font-bold">Cadastre-se</a>
              </p>
            </div>
          </div>
          
          <div className="mt-8 text-center text-sm text-gray-500">
            <p>Ao entrar, você concorda com nossos <a href="#" className="text-green-500 hover:text-green-400">Termos de Uso</a> e <a href="#" className="text-green-500 hover:text-green-400">Política de Privacidade</a>.</p>
            <p className="mt-2">Jogue com responsabilidade. Proibido para menores de 18 anos.</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  );
}
