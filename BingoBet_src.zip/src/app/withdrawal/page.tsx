import React, { useState } from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';

export default function WithdrawalPage() {
  const [selectedMethod, setSelectedMethod] = useState<'pix' | 'bank_transfer' | 'crypto'>('pix');
  const [amount, setAmount] = useState('100');
  const [withdrawalSubmitted, setWithdrawalSubmitted] = useState(false);

  const handleSubmit = () => {
    // Simulação de envio do pedido de saque
    setWithdrawalSubmitted(true);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Withdrawal Page */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h1 className="text-3xl font-bold mb-8">
            Realizar <span className="text-green-500">Saque</span>
          </h1>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left Column - Withdrawal Methods */}
            <div className="md:col-span-1">
              <div className="bg-gray-800 rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Métodos de Saque</h2>
                <div className="space-y-2">
                  <button 
                    className={`w-full text-left p-3 rounded-md flex items-center space-x-3 ${selectedMethod === 'pix' ? 'bg-green-900 border border-green-500' : 'bg-gray-700 hover:bg-gray-600'}`}
                    onClick={() => setSelectedMethod('pix')}
                  >
                    <span className="text-2xl">🔄</span>
                    <div>
                      <p className="font-bold">PIX</p>
                      <p className="text-xs text-gray-400">Instantâneo, sem taxas</p>
                    </div>
                  </button>
                  
                  <button 
                    className={`w-full text-left p-3 rounded-md flex items-center space-x-3 ${selectedMethod === 'bank_transfer' ? 'bg-green-900 border border-green-500' : 'bg-gray-700 hover:bg-gray-600'}`}
                    onClick={() => setSelectedMethod('bank_transfer')}
                  >
                    <span className="text-2xl">🏦</span>
                    <div>
                      <p className="font-bold">Transferência Bancária</p>
                      <p className="text-xs text-gray-400">1-2 dias úteis, sem taxas</p>
                    </div>
                  </button>
                  
                  <button 
                    className={`w-full text-left p-3 rounded-md flex items-center space-x-3 ${selectedMethod === 'crypto' ? 'bg-green-900 border border-green-500' : 'bg-gray-700 hover:bg-gray-600'}`}
                    onClick={() => setSelectedMethod('crypto')}
                  >
                    <span className="text-2xl">₿</span>
                    <div>
                      <p className="font-bold">Criptomoedas</p>
                      <p className="text-xs text-gray-400">10-30 minutos, taxa variável</p>
                    </div>
                  </button>
                </div>
                
                <div className="mt-6 p-4 bg-gray-700 rounded-lg">
                  <h3 className="font-bold mb-2">Valores Sugeridos</h3>
                  <div className="grid grid-cols-3 gap-2">
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('50')}
                    >
                      R$ 50
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('100')}
                    >
                      R$ 100
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('200')}
                    >
                      R$ 200
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('500')}
                    >
                      R$ 500
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('1000')}
                    >
                      R$ 1000
                    </button>
                    <button 
                      className="bg-gray-600 hover:bg-green-700 text-white font-bold py-2 rounded-md transition-colors"
                      onClick={() => setAmount('2000')}
                    >
                      R$ 2000
                    </button>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Right Column - Withdrawal Form or Confirmation */}
            <div className="md:col-span-2">
              {!withdrawalSubmitted ? (
                <div className="bg-gray-800 rounded-lg p-6">
                  <h3 className="text-xl font-bold mb-4">
                    {selectedMethod === 'pix' && 'Saque via PIX'}
                    {selectedMethod === 'bank_transfer' && 'Saque via Transferência Bancária'}
                    {selectedMethod === 'crypto' && 'Saque via Criptomoeda'}
                  </h3>
                  
                  <div className="mb-6">
                    <label htmlFor="amount" className="block text-gray-300 mb-2">Valor do Saque (R$)</label>
                    <div className="relative">
                      <span className="absolute left-3 top-2 text-gray-400">R$</span>
                      <input 
                        type="text" 
                        id="amount" 
                        className="w-full bg-gray-700 rounded-md pl-10 pr-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        placeholder="0,00"
                        value={amount}
                        onChange={(e) => setAmount(e.target.value)}
                      />
                    </div>
                    <p className="text-sm text-gray-400 mt-1">Saldo disponível: R$ 2.500,00</p>
                  </div>
                  
                  {selectedMethod === 'pix' && (
                    <div className="mb-6">
                      <label htmlFor="pix_key" className="block text-gray-300 mb-2">Chave PIX</label>
                      <input 
                        type="text" 
                        id="pix_key" 
                        className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        placeholder="CPF, e-mail, telefone ou chave aleatória"
                      />
                      <p className="text-sm text-gray-400 mt-1">Informe a chave PIX para receber o valor</p>
                    </div>
                  )}
                  
                  {selectedMethod === 'bank_transfer' && (
                    <div className="space-y-4 mb-6">
                      <div>
                        <label htmlFor="bank" className="block text-gray-300 mb-2">Banco</label>
                        <select 
                          id="bank" 
                          className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        >
                          <option value="">Selecione seu banco</option>
                          <option value="itau">Itaú</option>
                          <option value="bradesco">Bradesco</option>
                          <option value="santander">Santander</option>
                          <option value="bb">Banco do Brasil</option>
                          <option value="caixa">Caixa Econômica</option>
                          <option value="nubank">Nubank</option>
                        </select>
                      </div>
                      
                      <div>
                        <label htmlFor="agency" className="block text-gray-300 mb-2">Agência</label>
                        <input 
                          type="text" 
                          id="agency" 
                          className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                          placeholder="0000"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="account" className="block text-gray-300 mb-2">Conta</label>
                        <input 
                          type="text" 
                          id="account" 
                          className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                          placeholder="00000-0"
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="account_type" className="block text-gray-300 mb-2">Tipo de Conta</label>
                        <select 
                          id="account_type" 
                          className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        >
                          <option value="checking">Conta Corrente</option>
                          <option value="savings">Conta Poupança</option>
                        </select>
                      </div>
                    </div>
                  )}
                  
                  {selectedMethod === 'crypto' && (
                    <div className="space-y-4 mb-6">
                      <div>
                        <label htmlFor="crypto" className="block text-gray-300 mb-2">Criptomoeda</label>
                        <select 
                          id="crypto" 
                          className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        >
                          <option value="btc">Bitcoin (BTC)</option>
                          <option value="eth">Ethereum (ETH)</option>
                          <option value="usdt">Tether (USDT)</option>
                          <option value="ltc">Litecoin (LTC)</option>
                        </select>
                      </div>
                      
                      <div>
                        <label htmlFor="wallet" className="block text-gray-300 mb-2">Endereço da Carteira</label>
                        <input 
                          type="text" 
                          id="wallet" 
                          className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                          placeholder="Endereço da sua carteira de criptomoedas"
                        />
                        <p className="text-sm text-gray-400 mt-1">Certifique-se de que o endereço está correto. Transações de criptomoedas são irreversíveis.</p>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-gray-300">Total a receber:</p>
                      <p className="text-2xl font-bold text-white">
                        R$ {amount || '0,00'}
                      </p>
                    </div>
                    <button 
                      className="btn-primary px-8 py-3"
                      onClick={handleSubmit}
                    >
                      Solicitar Saque
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-gray-800 rounded-lg p-6 text-center">
                  <div className="h-24 w-24 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                    </svg>
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Solicitação de Saque Enviada!</h3>
                  <div className="bg-gray-700 rounded-lg p-6 mb-6 text-left">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-gray-400 text-sm">Método:</p>
                        <p className="font-bold">
                          {selectedMethod === 'pix' && 'PIX'}
                          {selectedMethod === 'bank_transfer' && 'Transferência Bancária'}
                          {selectedMethod === 'crypto' && 'Criptomoeda'}
                        </p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Valor:</p>
                        <p className="font-bold">R$ {amount}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Status:</p>
                        <p className="font-bold text-yellow-500">Em processamento</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">ID da Transação:</p>
                        <p className="font-bold">WD-{Math.floor(Math.random() * 1000000)}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Data:</p>
                        <p className="font-bold">{new Date().toLocaleDateString()}</p>
                      </div>
                      <div>
                        <p className="text-gray-400 text-sm">Tempo Estimado:</p>
                        <p className="font-bold">
                          {selectedMethod === 'pix' && 'Até 30 minutos'}
                          {selectedMethod === 'bank_transfer' && '1-2 dias úteis'}
                          {selectedMethod === 'crypto' && '10-30 minutos'}
                        </p>
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-300 mb-6">
                    Sua solicitação de saque foi recebida e está sendo processada. Você receberá uma notificação quando o pagamento for concluído.
                  </p>
                  <button 
                    className="btn-secondary"
                    onClick={() => setWithdrawalSubmitted(false)}
                  >
                    Voltar
                  </button>
                </div>
              )}
            </div>
          </div>
          
          {/* Withdrawal Information */}
          <div className="mt-12 bg-gray-800 rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Informações Importantes</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-gray-700 p-4 rounded-lg">
                <h3 className="font-bold text-green-500 mb-2">Processamento de Saques</h3>
                <p className="text-gray-300 text-sm">
                  Saques via PIX são processados em até 30 minutos. Transferências bancárias podem levar de 1 a 2 dias úteis para serem concluídas.
                </p>
              </div>
              
              <div className="bg-gray-700 p-4 rounded-lg">
                <h3 className="font-bold text-yellow-500 mb-2">Limites de Saque</h3>
                <p className="text-gray-300 text-sm">
                  Valor mínimo: R$ 30<br />
                  Valor máximo: R$ 10.000 por transação<br />
                  Limite mensal: R$ 50.000
                </p>
              </div>
              
              <div className="bg-gray-700 p-4 rounded-lg">
                <h3 className="font-bold text-red-500 mb-2">Verificação</h3>
                <p className="text-gray-300 text-sm">
                  Para saques acima de R$ 1.000, pode ser necessário enviar documentos adicionais para verificação. Isso é uma medida de segurança para proteger sua conta.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
