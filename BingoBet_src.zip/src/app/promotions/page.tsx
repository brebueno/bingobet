import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import PromotionCard from '../../components/ui/PromotionCard';

export default function PromotionsPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Promotions Hero */}
      <section className="bg-gradient-to-r from-yellow-900 to-yellow-800 py-12">
        <div className="container-main text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Promoções <span className="text-green-500">Especiais</span>
          </h1>
          <p className="text-xl mb-6 max-w-3xl mx-auto">
            Aproveite nossas ofertas exclusivas e multiplique suas chances de ganhar na BingoBet!
          </p>
        </div>
      </section>

      {/* Welcome Promotions */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-2xl font-bold mb-6">
            Promoções de <span className="text-green-500">Boas-vindas</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
            <PromotionCard 
              title="Bingo Grátis"
              description="Novos usuários ganham 5 cartelas sem depósito! Experimente nossa plataforma sem compromisso."
              buttonText="Cadastre-se Agora"
              variant="primary"
            />
            
            <PromotionCard 
              title="Bônus de Primeiro Depósito"
              description="100% de bônus até R$200 no seu primeiro depósito. Dobre seu dinheiro e aumente suas chances!"
              buttonText="Depositar"
              variant="secondary"
            />
          </div>

          <h2 className="text-2xl font-bold mb-6">
            Promoções <span className="text-green-500">Recorrentes</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            <div className="card border border-gray-700">
              <div className="bg-green-900 rounded-t-lg p-3">
                <h3 className="text-xl font-bold">Cashback Semanal</h3>
              </div>
              <div className="p-4">
                <p className="text-gray-300 mb-4">
                  Receba 10% de cashback sobre suas perdas toda semana. Creditamos automaticamente em sua conta toda segunda-feira.
                </p>
                <button className="btn-primary w-full">Saiba Mais</button>
              </div>
            </div>
            
            <div className="card border border-gray-700">
              <div className="bg-green-900 rounded-t-lg p-3">
                <h3 className="text-xl font-bold">Happy Hour</h3>
              </div>
              <div className="p-4">
                <p className="text-gray-300 mb-4">
                  De segunda a sexta, das 18h às 20h, todas as cartelas de bingo têm 50% de desconto! Aproveite para jogar mais pagando menos.
                </p>
                <button className="btn-primary w-full">Saiba Mais</button>
              </div>
            </div>
            
            <div className="card border border-gray-700">
              <div className="bg-green-900 rounded-t-lg p-3">
                <h3 className="text-xl font-bold">Missões Diárias</h3>
              </div>
              <div className="p-4">
                <p className="text-gray-300 mb-4">
                  Complete missões diárias e ganhe recompensas exclusivas como cartelas grátis, bônus e até dinheiro real!
                </p>
                <button className="btn-primary w-full">Saiba Mais</button>
              </div>
            </div>
          </div>

          <h2 className="text-2xl font-bold mb-6">
            Programas <span className="text-green-500">Especiais</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <PromotionCard 
              title="Indique um Amigo"
              description="Ganhe R$20 para cada amigo que se cadastrar e fizer um depósito. Seu amigo também ganha R$20 de bônus!"
              buttonText="Indicar Agora"
              variant="secondary"
            />
            
            <PromotionCard 
              title="Clube VIP"
              description="Jogue regularmente e suba de nível em nosso programa de fidelidade. Ganhe recompensas exclusivas, cashback aumentado e atendimento prioritário."
              buttonText="Conhecer Clube VIP"
              variant="primary"
            />
          </div>
        </div>
      </section>

      {/* Calendar */}
      <section className="py-12 bg-gray-800">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8 text-center">
            Calendário de <span className="text-yellow-500">Eventos</span>
          </h2>
          
          <div className="card border border-gray-700 overflow-hidden">
            <div className="bg-green-900 p-4">
              <h3 className="text-xl font-bold text-center">Eventos Especiais de Abril 2025</h3>
            </div>
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-yellow-500 text-black font-bold rounded-lg p-2 text-center min-w-16">
                    <div className="text-sm">ABR</div>
                    <div className="text-2xl">25</div>
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">Super Bingo de Sexta</h4>
                    <p className="text-gray-300">Prêmio garantido de R$10.000! Cartelas a partir de R$5.</p>
                    <p className="text-sm text-gray-400 mt-1">20:00 - 22:00</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-yellow-500 text-black font-bold rounded-lg p-2 text-center min-w-16">
                    <div className="text-sm">ABR</div>
                    <div className="text-2xl">27</div>
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">Torneio de Truco</h4>
                    <p className="text-gray-300">Campeonato mensal com prêmio total de R$5.000.</p>
                    <p className="text-sm text-gray-400 mt-1">15:00 - 21:00</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-yellow-500 text-black font-bold rounded-lg p-2 text-center min-w-16">
                    <div className="text-sm">ABR</div>
                    <div className="text-2xl">30</div>
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">Bingo Temático</h4>
                    <p className="text-gray-300">Bingo especial com tema "Carnaval" e prêmios exclusivos.</p>
                    <p className="text-sm text-gray-400 mt-1">19:00 - 23:00</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-4">
                  <div className="bg-green-500 text-black font-bold rounded-lg p-2 text-center min-w-16">
                    <div className="text-sm">MAI</div>
                    <div className="text-2xl">01</div>
                  </div>
                  <div>
                    <h4 className="text-lg font-bold">Bingo do Trabalhador</h4>
                    <p className="text-gray-300">Evento especial com cartelas grátis e prêmios em dobro!</p>
                    <p className="text-sm text-gray-400 mt-1">14:00 - 22:00</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Terms */}
      <section className="py-12 bg-gray-900">
        <div className="container-main max-w-4xl">
          <h2 className="text-2xl font-bold mb-6 text-center">
            Termos e <span className="text-green-500">Condições</span>
          </h2>
          
          <div className="card border border-gray-700">
            <div className="p-6">
              <ul className="space-y-4 text-gray-300 text-sm">
                <li>• Todas as promoções estão sujeitas a requisitos de apostas. Consulte os termos específicos de cada promoção.</li>
                <li>• O bônus de boas-vindas deve ser utilizado em até 7 dias após o cadastro.</li>
                <li>• O cashback semanal é calculado com base nas perdas líquidas de segunda a domingo.</li>
                <li>• Promoções podem ser alteradas ou encerradas a qualquer momento, a critério da BingoBet.</li>
                <li>• Apenas usuários maiores de 18 anos podem participar das promoções.</li>
                <li>• A BingoBet se reserva o direito de cancelar bônus e ganhos em caso de uso indevido ou suspeita de fraude.</li>
              </ul>
              <div className="mt-6 text-center">
                <button className="btn-secondary">Ver Termos Completos</button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
