import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import ProviderAPI from '../../components/admin/ProviderAPI';

export default function APIIntegrationPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Admin Header */}
      <section className="bg-gradient-to-r from-gray-900 to-gray-800 py-8 border-b border-gray-700">
        <div className="container-main">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <h1 className="text-3xl font-bold mb-4 md:mb-0">Painel de Administração</h1>
            <div className="flex space-x-4">
              <button className="btn-primary">Dashboard</button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Provedores</button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Jogos</button>
            </div>
          </div>
        </div>
      </section>

      {/* API Integration */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Integração de <span className="text-green-500">API</span>
          </h2>
          
          <div className="mb-8">
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Status da Integração</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">APIs Conectadas</p>
                      <p className="text-3xl font-bold text-white">3/8</p>
                    </div>
                    <div className="h-12 w-12 bg-green-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">Requisições/Hora</p>
                      <p className="text-3xl font-bold text-white">1.256</p>
                    </div>
                    <div className="h-12 w-12 bg-yellow-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                      </svg>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">Taxa de Sucesso</p>
                      <p className="text-3xl font-bold text-green-500">99.8%</p>
                    </div>
                    <div className="h-12 w-12 bg-green-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <h3 className="text-xl font-bold mb-4">Provedores Principais</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <ProviderAPI 
              provider="PG Soft"
              apiEndpoint="https://api.pgsoft.com/v1/games"
              apiKey="pg_live_8f7h3j2k5l6m9n0p1q2r3s4t5u6v7w8x"
              status="connected"
            />
            
            <ProviderAPI 
              provider="Evolution Gaming"
              apiEndpoint="https://api.evolution.com/v2/games"
              apiKey="evo_live_9n8m7l6k5j4h3g2f1d0s9a8b7c6d5e"
              status="connected"
            />
            
            <ProviderAPI 
              provider="Spribe"
              apiEndpoint="https://api.spribe.io/v1/games"
              apiKey="spribe_live_1a2b3c4d5e6f7g8h9i0j1k2l3m4n5o"
              status="connected"
            />
            
            <ProviderAPI 
              provider="Pragmatic Play"
              apiEndpoint="https://api.pragmaticplay.com/v1/games"
              apiKey="pragmatic_live_5p6o7i8u9y0t5r4e3w2q1"
              status="pending"
            />
          </div>
          
          <h3 className="text-xl font-bold mb-4">Provedores Adicionais</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <ProviderAPI 
              provider="Playson"
              apiEndpoint="https://api.playson.com/v1/games"
              apiKey="playson_live_1q2w3e4r5t6y7u8i9o0p"
              status="disconnected"
            />
            
            <ProviderAPI 
              provider="Nsoft"
              apiEndpoint="https://api.nsoft.com/v1/games"
              apiKey="nsoft_live_9o8i7u6y5t4r3e2w1q"
              status="disconnected"
            />
            
            <ProviderAPI 
              provider="BGaming"
              apiEndpoint="https://api.bgaming.com/v1/games"
              apiKey="bgaming_live_2a3s4d5f6g7h8j9k0l"
              status="disconnected"
            />
            
            <ProviderAPI 
              provider="Red Tiger"
              apiEndpoint="https://api.redtiger.com/v1/games"
              apiKey="redtiger_live_9z8x7c6v5b4n3m2l1k"
              status="disconnected"
            />
          </div>
        </div>
      </section>

      {/* API Testing */}
      <section className="py-12 bg-gray-800">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Teste de <span className="text-green-500">API</span>
          </h2>
          
          <div className="bg-gray-900 rounded-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Requisição</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-300 mb-2">Provedor</label>
                    <select className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500">
                      <option value="pgsoft">PG Soft</option>
                      <option value="evolution">Evolution Gaming</option>
                      <option value="spribe">Spribe</option>
                      <option value="pragmatic">Pragmatic Play</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Endpoint</label>
                    <select className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500">
                      <option value="games">GET /games</option>
                      <option value="game">GET /game/{'{id}'}</option>
                      <option value="session">POST /session/create</option>
                      <option value="balance">GET /player/balance</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Parâmetros</label>
                    <textarea 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500 h-32"
                      placeholder='{"gameId": "fortune_tiger", "currency": "BRL", "language": "pt-BR"}'
                    ></textarea>
                  </div>
                  
                  <button className="btn-primary w-full">Enviar Requisição</button>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4">Resposta</h3>
                <div className="bg-gray-700 rounded-lg p-4 h-96 overflow-auto">
                  <pre className="text-green-400 text-sm">
{`{
  "status": "success",
  "code": 200,
  "data": {
    "games": [
      {
        "id": "fortune_tiger",
        "name": "Fortune Tiger",
        "provider": "PG Soft",
        "category": "slots",
        "thumbnail": "https://api.pgsoft.com/images/fortune_tiger.jpg",
        "isPopular": true,
        "isNew": false,
        "rtp": 96.5,
        "minBet": 0.20,
        "maxBet": 100.00,
        "features": ["freespins", "multiplier", "bonus"],
        "supportedCurrencies": ["BRL", "USD", "EUR"],
        "supportedLanguages": ["pt-BR", "en-US", "es-ES"]
      },
      {
        "id": "fortune_rabbit",
        "name": "Fortune Rabbit",
        "provider": "PG Soft",
        "category": "slots",
        "thumbnail": "https://api.pgsoft.com/images/fortune_rabbit.jpg",
        "isPopular": false,
        "isNew": true,
        "rtp": 97.0,
        "minBet": 0.20,
        "maxBet": 100.00,
        "features": ["freespins", "multiplier", "bonus"],
        "supportedCurrencies": ["BRL", "USD", "EUR"],
        "supportedLanguages": ["pt-BR", "en-US", "es-ES"]
      }
    ],
    "pagination": {
      "page": 1,
      "pageSize": 10,
      "totalItems": 136,
      "totalPages": 14
    }
  }
}`}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Integration Logs */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Logs de <span className="text-green-500">Integração</span>
          </h2>
          
          <div className="bg-gray-800 rounded-lg p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold">Últimos Eventos</h3>
              <div className="flex space-x-4">
                <select className="bg-gray-700 text-white px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
                  <option value="all">Todos os Níveis</option>
                  <option value="info">Info</option>
                  <option value="warning">Warning</option>
                  <option value="error">Error</option>
                </select>
                <button className="btn-secondary">Limpar Logs</button>
              </div>
            </div>
            
            <div className="bg-gray-900 rounded-lg p-4 h-64 overflow-y-auto">
              <div className="space-y-2">
                <div className="flex items-start">
                  <span className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded mr-2">INFO</span>
                  <div>
                    <p className="text-white">[2025-04-21 18:45:12] Conexão estabelecida com PG Soft API</p>
                    <p className="text-gray-400 text-sm">Resposta: 200 OK</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <span className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded mr-2">INFO</span>
                  <div>
                    <p className="text-white">[2025-04-21 18:44:58] Conexão estabelecida com Evolution Gaming API</p>
                    <p className="text-gray-400 text-sm">Resposta: 200 OK</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <span className="bg-yellow-600 text-white text-xs font-bold px-2 py-1 rounded mr-2">WARN</span>
                  <div>
                    <p className="text-white">[2025-04-21 18:44:32] Latência alta na resposta da Pragmatic Play API</p>
                    <p className="text-gray-400 text-sm">Tempo de resposta: 3245ms</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <span className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded mr-2">INFO</span>
                  <div>
                    <p className="text-white">[2025-04-21 18:44:05] Conexão estabelecida com Spribe API</p>
                    <p className="text-gray-400 text-sm">Resposta: 200 OK</p>
                  </div>
                </div>
                
                <div className="flex items-start">
                  <span className="bg-red-600 text-white text-xs font-bold px-2 py-1 rounded mr-2">ERROR</span>
                  <div>
                    <p className="text-white">[2025-04-21 18:43:47] Falha na conexão com Red Tiger API</p>
                    <p className="text-gray-400 text-sm">Erro: 401 Unauthorized - Chave de API inválida</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
