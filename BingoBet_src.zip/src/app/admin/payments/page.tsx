import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import PaymentMethod from '../../components/admin/PaymentMethod';

export default function PaymentsPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Admin Header */}
      <section className="bg-gradient-to-r from-gray-900 to-gray-800 py-8 border-b border-gray-700">
        <div className="container-main">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <h1 className="text-3xl font-bold mb-4 md:mb-0">Painel de Administração</h1>
            <div className="flex space-x-4">
              <button className="btn-primary">Dashboard</button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Provedores</button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Relatórios</button>
            </div>
          </div>
        </div>
      </section>

      {/* Payment Methods */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Métodos de <span className="text-green-500">Pagamento</span>
          </h2>
          
          <div className="mb-8">
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Status do Sistema de Pagamentos</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">Métodos Ativos</p>
                      <p className="text-3xl font-bold text-white">3/8</p>
                    </div>
                    <div className="h-12 w-12 bg-green-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">Transações/Dia</p>
                      <p className="text-3xl font-bold text-white">1.458</p>
                    </div>
                    <div className="h-12 w-12 bg-yellow-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">Taxa de Sucesso</p>
                      <p className="text-3xl font-bold text-green-500">99.5%</p>
                    </div>
                    <div className="h-12 w-12 bg-green-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <h3 className="text-xl font-bold mb-4">Métodos de Depósito</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <PaymentMethod 
              name="PIX"
              icon="🔄"
              isPopular={true}
              isInstant={true}
              processingTime="Instantâneo"
              fee="Grátis"
            />
            
            <PaymentMethod 
              name="Cartão de Crédito"
              icon="💳"
              isPopular={true}
              isInstant={true}
              processingTime="Instantâneo"
              fee="2.5%"
            />
            
            <PaymentMethod 
              name="Transferência Bancária"
              icon="🏦"
              processingTime="1-2 dias úteis"
              fee="Grátis"
            />
            
            <PaymentMethod 
              name="Boleto Bancário"
              icon="📃"
              processingTime="1-3 dias úteis"
              fee="R$ 2,50"
            />
          </div>
          
          <h3 className="text-xl font-bold mb-4">Métodos de Saque</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <PaymentMethod 
              name="PIX"
              icon="🔄"
              isPopular={true}
              isInstant={true}
              processingTime="Instantâneo"
              fee="Grátis"
            />
            
            <PaymentMethod 
              name="Transferência Bancária"
              icon="🏦"
              processingTime="1-2 dias úteis"
              fee="Grátis"
            />
            
            <PaymentMethod 
              name="Carteira Digital"
              icon="📱"
              isInstant={true}
              processingTime="Instantâneo"
              fee="1%"
            />
            
            <PaymentMethod 
              name="Criptomoedas"
              icon="₿"
              processingTime="10-30 minutos"
              fee="Variável"
            />
          </div>
        </div>
      </section>

      {/* Payment Gateway Configuration */}
      <section className="py-12 bg-gray-800">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Configuração de <span className="text-green-500">Gateway</span>
          </h2>
          
          <div className="bg-gray-900 rounded-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Credenciais do Gateway</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-300 mb-2">Gateway Principal</label>
                    <select className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500">
                      <option value="mercadopago">Mercado Pago</option>
                      <option value="pagseguro">PagSeguro</option>
                      <option value="paypal">PayPal</option>
                      <option value="stripe">Stripe</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">API Key</label>
                    <div className="flex">
                      <input 
                        type="text" 
                        className="flex-1 bg-gray-700 rounded-l-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        value="****************************************"
                        readOnly
                      />
                      <button className="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-r-md transition-colors">
                        Mostrar
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">API Secret</label>
                    <div className="flex">
                      <input 
                        type="text" 
                        className="flex-1 bg-gray-700 rounded-l-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        value="****************************************"
                        readOnly
                      />
                      <button className="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-r-md transition-colors">
                        Mostrar
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Ambiente</label>
                    <div className="flex space-x-4">
                      <div className="flex items-center">
                        <input type="radio" id="sandbox" name="environment" className="mr-2" checked />
                        <label htmlFor="sandbox" className="text-gray-300">Sandbox</label>
                      </div>
                      <div className="flex items-center">
                        <input type="radio" id="production" name="environment" className="mr-2" />
                        <label htmlFor="production" className="text-gray-300">Produção</label>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4">Configurações de Webhook</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-300 mb-2">URL de Callback</label>
                    <input 
                      type="text" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="https://bingobet.com/api/payments/callback"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Eventos</label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center">
                        <input type="checkbox" id="event-payment-success" className="mr-2" checked />
                        <label htmlFor="event-payment-success" className="text-gray-300">Pagamento Aprovado</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-payment-failure" className="mr-2" checked />
                        <label htmlFor="event-payment-failure" className="text-gray-300">Pagamento Recusado</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-refund" className="mr-2" checked />
                        <label htmlFor="event-refund" className="text-gray-300">Reembolso</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-chargeback" className="mr-2" checked />
                        <label htmlFor="event-chargeback" className="text-gray-300">Chargeback</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-withdrawal" className="mr-2" checked />
                        <label htmlFor="event-withdrawal" className="text-gray-300">Saque</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-error" className="mr-2" checked />
                        <label htmlFor="event-error" className="text-gray-300">Erro</label>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <button className="btn-primary">Salvar Configurações</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* PIX Configuration */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Configuração do <span className="text-green-500">PIX</span>
          </h2>
          
          <div className="bg-gray-800 rounded-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Chaves PIX</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-300 mb-2">Tipo de Chave Principal</label>
                    <select className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500">
                      <option value="cnpj">CNPJ</option>
                      <option value="email">E-mail</option>
                      <option value="phone">Telefone</option>
                      <option value="random">Chave Aleatória</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Chave PIX</label>
                    <input 
                      type="text" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="12.345.678/0001-90"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Nome do Beneficiário</label>
                    <input 
                      type="text" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="BingoBet Entretenimento LTDA"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Cidade</label>
                    <input 
                      type="text" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="São Paulo"
                    />
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4">Configurações Avançadas</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-300 mb-2">Tempo de Expiração (minutos)</label>
                    <input 
                      type="number" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="30"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Valor Mínimo (R$)</label>
                    <input 
                      type="number" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="10"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Valor Máximo (R$)</label>
                    <input 
                      type="number" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="10000"
                    />
                  </div>
                  
                  <div className="flex items-center">
                    <input type="checkbox" id="auto-confirm" className="mr-2" checked />
                    <label htmlFor="auto-confirm" className="text-gray-300">Confirmação Automática</label>
                  </div>
                  
                  <div className="flex items-center">
                    <input type="checkbox" id="qr-code" className="mr-2" checked />
                    <label htmlFor="qr-code" className="text-gray-300">Gerar QR Code</label>
                  </div>
                </div>
                
                <div className="mt-6">
                  <button className="btn-primary">Salvar Configurações</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
