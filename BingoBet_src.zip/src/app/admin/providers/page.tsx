import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import ProviderIntegration from '../../components/admin/ProviderIntegration';

export default function ProvidersPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Admin Header */}
      <section className="bg-gradient-to-r from-gray-900 to-gray-800 py-8 border-b border-gray-700">
        <div className="container-main">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <h1 className="text-3xl font-bold mb-4 md:mb-0">Painel de Administração</h1>
            <div className="flex space-x-4">
              <button className="btn-primary">Dashboard</button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Usuários</button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Relatórios</button>
            </div>
          </div>
        </div>
      </section>

      {/* Providers Integration */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Integração de <span className="text-green-500">Provedores</span>
          </h2>
          
          <div className="mb-8">
            <div className="bg-gray-800 p-6 rounded-lg">
              <h3 className="text-xl font-bold mb-4">Status da Integração</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">Provedores Integrados</p>
                      <p className="text-3xl font-bold text-white">3/24</p>
                    </div>
                    <div className="h-12 w-12 bg-green-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">Jogos Disponíveis</p>
                      <p className="text-3xl font-bold text-white">156</p>
                    </div>
                    <div className="h-12 w-12 bg-yellow-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-700 rounded-lg p-4">
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-sm text-gray-400">API Status</p>
                      <p className="text-3xl font-bold text-green-500">Online</p>
                    </div>
                    <div className="h-12 w-12 bg-green-600 rounded-full flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <h3 className="text-xl font-bold mb-4">Provedores Principais</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <ProviderIntegration 
              provider="PG Soft"
              gameCount={136}
              logo="PG"
              isPopular={true}
            />
            
            <ProviderIntegration 
              provider="Evolution Gaming"
              gameCount={209}
              logo="Evolution"
              isPopular={true}
            />
            
            <ProviderIntegration 
              provider="Spribe"
              gameCount={8}
              logo="SPRIBE"
              isPopular={true}
            />
            
            <ProviderIntegration 
              provider="Pragmatic Play"
              gameCount={240}
              logo="Pragmatic"
              isPopular={true}
            />
          </div>
          
          <h3 className="text-xl font-bold mb-4">Provedores Adicionais</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <ProviderIntegration 
              provider="Playson"
              gameCount={27}
              logo="Playson"
            />
            
            <ProviderIntegration 
              provider="Nsoft"
              gameCount={48}
              logo="Nsoft"
            />
            
            <ProviderIntegration 
              provider="1x2 Gaming"
              gameCount={3}
              logo="1x2"
            />
            
            <ProviderIntegration 
              provider="Banana Games"
              gameCount={4}
              logo="Banana"
            />
            
            <ProviderIntegration 
              provider="Endorphina"
              gameCount={77}
              logo="Endorphina"
            />
            
            <ProviderIntegration 
              provider="Popok"
              gameCount={25}
              logo="POPOK"
            />
            
            <ProviderIntegration 
              provider="BGaming"
              gameCount={19}
              logo="BGaming"
            />
            
            <ProviderIntegration 
              provider="Red Tiger"
              gameCount={199}
              logo="Red Tiger"
            />
          </div>
        </div>
      </section>

      {/* API Configuration */}
      <section className="py-12 bg-gray-800">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Configuração de <span className="text-green-500">API</span>
          </h2>
          
          <div className="bg-gray-900 rounded-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Credenciais de API</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-300 mb-2">API Key</label>
                    <div className="flex">
                      <input 
                        type="text" 
                        className="flex-1 bg-gray-700 rounded-l-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        value="****************************************"
                        readOnly
                      />
                      <button className="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-r-md transition-colors">
                        Mostrar
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">API Secret</label>
                    <div className="flex">
                      <input 
                        type="text" 
                        className="flex-1 bg-gray-700 rounded-l-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                        value="****************************************"
                        readOnly
                      />
                      <button className="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-r-md transition-colors">
                        Mostrar
                      </button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Endpoint Base</label>
                    <input 
                      type="text" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="https://api.bingobet.com/v1/"
                      readOnly
                    />
                  </div>
                </div>
                
                <div className="mt-6">
                  <button className="btn-primary">Gerar Novas Credenciais</button>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4">Configurações de Webhook</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-300 mb-2">URL de Callback</label>
                    <input 
                      type="text" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="https://bingobet.com/api/callback"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Eventos</label>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="flex items-center">
                        <input type="checkbox" id="event-game-start" className="mr-2" checked />
                        <label htmlFor="event-game-start" className="text-gray-300">Início de Jogo</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-game-end" className="mr-2" checked />
                        <label htmlFor="event-game-end" className="text-gray-300">Fim de Jogo</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-win" className="mr-2" checked />
                        <label htmlFor="event-win" className="text-gray-300">Vitória</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-deposit" className="mr-2" checked />
                        <label htmlFor="event-deposit" className="text-gray-300">Depósito</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-withdrawal" className="mr-2" checked />
                        <label htmlFor="event-withdrawal" className="text-gray-300">Saque</label>
                      </div>
                      <div className="flex items-center">
                        <input type="checkbox" id="event-error" className="mr-2" checked />
                        <label htmlFor="event-error" className="text-gray-300">Erro</label>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <button className="btn-primary">Salvar Configurações</button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Integration Code */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Código de <span className="text-green-500">Integração</span>
          </h2>
          
          <div className="bg-gray-800 rounded-lg p-6">
            <h3 className="text-xl font-bold mb-4">Exemplo de Integração</h3>
            <div className="bg-gray-900 rounded-lg p-4 overflow-x-auto">
              <pre className="text-gray-300 text-sm">
{`// Exemplo de integração com PG Soft
import { PGSoftClient } from '@bingobet/providers';

// Inicializar cliente
const pgClient = new PGSoftClient({
  apiKey: 'SUA_API_KEY',
  apiSecret: 'SUA_API_SECRET',
  endpoint: 'https://api.bingobet.com/v1/pgsoft'
});

// Obter lista de jogos
const getGames = async () => {
  try {
    const games = await pgClient.getGames();
    console.log(\`Jogos disponíveis: \${games.length}\`);
    return games;
  } catch (error) {
    console.error('Erro ao obter jogos:', error);
  }
};

// Iniciar sessão de jogo
const startGameSession = async (gameId, userId) => {
  try {
    const session = await pgClient.createGameSession({
      gameId,
      userId,
      currency: 'BRL',
      language: 'pt-BR'
    });
    
    return session.gameUrl; // URL para redirecionar o jogador
  } catch (error) {
    console.error('Erro ao iniciar sessão de jogo:', error);
  }
};

// Processar resultado de jogo (webhook)
const processGameResult = (result) => {
  const { userId, gameId, bet, win, timestamp } = result;
  
  // Atualizar saldo do usuário
  updateUserBalance(userId, win - bet);
  
  // Registrar transação
  logTransaction({
    userId,
    gameId,
    bet,
    win,
    timestamp,
    provider: 'PG Soft'
  });
};`}
              </pre>
            </div>
            
            <div className="mt-6 flex justify-end">
              <button className="btn-secondary">Copiar Código</button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
