import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import GameIntegration from '../../components/admin/GameIntegration';

export default function GamesIntegrationPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Admin Header */}
      <section className="bg-gradient-to-r from-gray-900 to-gray-800 py-8 border-b border-gray-700">
        <div className="container-main">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <h1 className="text-3xl font-bold mb-4 md:mb-0">Painel de Administração</h1>
            <div className="flex space-x-4">
              <button className="btn-primary">Dashboard</button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Provedores</button>
              <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded-md">Relatórios</button>
            </div>
          </div>
        </div>
      </section>

      {/* Games Integration */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Integração de <span className="text-green-500">Jogos</span>
          </h2>
          
          <div className="mb-8">
            <div className="bg-gray-800 p-6 rounded-lg">
              <div className="flex flex-col md:flex-row justify-between items-center mb-6">
                <h3 className="text-xl font-bold mb-4 md:mb-0">Filtrar Jogos</h3>
                <div className="flex flex-wrap gap-4">
                  <select className="bg-gray-700 text-white px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
                    <option value="">Todos os Provedores</option>
                    <option value="pgsoft">PG Soft</option>
                    <option value="evolution">Evolution Gaming</option>
                    <option value="spribe">Spribe</option>
                    <option value="pragmatic">Pragmatic Play</option>
                  </select>
                  
                  <select className="bg-gray-700 text-white px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500">
                    <option value="">Todas as Categorias</option>
                    <option value="slots">Slots</option>
                    <option value="table">Jogos de Mesa</option>
                    <option value="live">Cassino ao Vivo</option>
                    <option value="bingo">Bingo</option>
                  </select>
                  
                  <input 
                    type="text" 
                    placeholder="Buscar jogos..." 
                    className="bg-gray-700 text-white px-4 py-2 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                  />
                </div>
              </div>
              
              <div className="flex flex-wrap gap-4">
                <button className="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-md transition-colors">
                  Todos
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold px-4 py-2 rounded-md transition-colors">
                  Populares
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold px-4 py-2 rounded-md transition-colors">
                  Novos
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold px-4 py-2 rounded-md transition-colors">
                  Slots
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold px-4 py-2 rounded-md transition-colors">
                  Cassino ao Vivo
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold px-4 py-2 rounded-md transition-colors">
                  Bingo
                </button>
                <button className="bg-gray-700 hover:bg-gray-600 text-white font-bold px-4 py-2 rounded-md transition-colors">
                  Jogos de Mesa
                </button>
              </div>
            </div>
          </div>
          
          <h3 className="text-xl font-bold mb-4">Jogos Populares</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <GameIntegration 
              gameId="pg_fortune_tiger"
              title="Fortune Tiger"
              provider="PG Soft"
              category="Slots"
              thumbnail="🐯"
              isPopular={true}
            />
            
            <GameIntegration 
              gameId="evolution_lightning_roulette"
              title="Lightning Roulette"
              provider="Evolution Gaming"
              category="Cassino ao Vivo"
              thumbnail="🎲"
              isPopular={true}
            />
            
            <GameIntegration 
              gameId="spribe_aviator"
              title="Aviator"
              provider="Spribe"
              category="Crash Games"
              thumbnail="✈️"
              isPopular={true}
            />
            
            <GameIntegration 
              gameId="pragmatic_sweet_bonanza"
              title="Sweet Bonanza"
              provider="Pragmatic Play"
              category="Slots"
              thumbnail="🍭"
              isPopular={true}
            />
          </div>
          
          <h3 className="text-xl font-bold mb-4">Jogos Recentes</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <GameIntegration 
              gameId="pg_fortune_rabbit"
              title="Fortune Rabbit"
              provider="PG Soft"
              category="Slots"
              thumbnail="🐰"
              isNew={true}
            />
            
            <GameIntegration 
              gameId="evolution_crazy_time"
              title="Crazy Time"
              provider="Evolution Gaming"
              category="Cassino ao Vivo"
              thumbnail="🎪"
              isNew={true}
            />
            
            <GameIntegration 
              gameId="pragmatic_gates_olympus"
              title="Gates of Olympus"
              provider="Pragmatic Play"
              category="Slots"
              thumbnail="⚡"
              isNew={true}
            />
            
            <GameIntegration 
              gameId="bgaming_elvis_frog"
              title="Elvis Frog"
              provider="BGaming"
              category="Slots"
              thumbnail="🐸"
              isNew={true}
            />
          </div>
          
          <h3 className="text-xl font-bold mb-4">Bingo e Jogos Brasileiros</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <GameIntegration 
              gameId="evolution_mega_ball"
              title="Mega Ball"
              provider="Evolution Gaming"
              category="Bingo"
              thumbnail="🎱"
            />
            
            <GameIntegration 
              gameId="nsoft_bingo"
              title="Bingo 90"
              provider="NSoft"
              category="Bingo"
              thumbnail="🎯"
            />
            
            <GameIntegration 
              gameId="playtech_truco"
              title="Truco Brasileiro"
              provider="Playtech"
              category="Jogos de Mesa"
              thumbnail="🃏"
            />
            
            <GameIntegration 
              gameId="ezugi_canastra"
              title="Canastra"
              provider="Ezugi"
              category="Jogos de Mesa"
              thumbnail="🎴"
            />
          </div>
        </div>
      </section>

      {/* Integration Settings */}
      <section className="py-12 bg-gray-800">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8">
            Configurações de <span className="text-green-500">Integração</span>
          </h2>
          
          <div className="bg-gray-900 rounded-lg p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Configurações Gerais</h3>
                <div className="space-y-4">
                  <div>
                    <label className="block text-gray-300 mb-2">Limite de RTP (Return to Player)</label>
                    <input 
                      type="range" 
                      min="85" 
                      max="98" 
                      value="96" 
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-gray-400">
                      <span>85%</span>
                      <span>96%</span>
                      <span>98%</span>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Modo de Integração</label>
                    <select className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500">
                      <option value="iframe">iFrame</option>
                      <option value="redirect">Redirecionamento</option>
                      <option value="api">API Direta</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Moeda Padrão</label>
                    <select className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500">
                      <option value="BRL">Real Brasileiro (BRL)</option>
                      <option value="USD">Dólar Americano (USD)</option>
                      <option value="EUR">Euro (EUR)</option>
                    </select>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4">Configurações Avançadas</h3>
                <div className="space-y-4">
                  <div className="flex items-center">
                    <input type="checkbox" id="demo-mode" className="mr-2" checked />
                    <label htmlFor="demo-mode" className="text-gray-300">Habilitar Modo Demo</label>
                  </div>
                  
                  <div className="flex items-center">
                    <input type="checkbox" id="auto-refresh" className="mr-2" checked />
                    <label htmlFor="auto-refresh" className="text-gray-300">Atualização Automática de Jogos</label>
                  </div>
                  
                  <div className="flex items-center">
                    <input type="checkbox" id="mobile-optimize" className="mr-2" checked />
                    <label htmlFor="mobile-optimize" className="text-gray-300">Otimização para Dispositivos Móveis</label>
                  </div>
                  
                  <div className="flex items-center">
                    <input type="checkbox" id="responsible-gaming" className="mr-2" checked />
                    <label htmlFor="responsible-gaming" className="text-gray-300">Ferramentas de Jogo Responsável</label>
                  </div>
                  
                  <div>
                    <label className="block text-gray-300 mb-2">Intervalo de Atualização de Catálogo (horas)</label>
                    <input 
                      type="number" 
                      className="w-full bg-gray-700 rounded-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                      value="24"
                    />
                  </div>
                </div>
              </div>
            </div>
            
            <div className="mt-8 flex justify-end">
              <button className="btn-primary">Salvar Configurações</button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
