import React, { useState } from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import DailyReward from '../../components/gamification/DailyReward';
import Mission from '../../components/gamification/Mission';
import LevelProgress from '../../components/gamification/LevelProgress';
import AchievementCard from '../../components/ui/AchievementCard';
import UserProfile from '../../components/ui/UserProfile';

export default function GamificationPage() {
  const [currentLevel, setCurrentLevel] = useState(5);
  const [currentXP, setCurrentXP] = useState(450);
  const [xpForNextLevel, setXpForNextLevel] = useState(600);
  
  // Missões diárias
  const dailyMissions = [
    {
      id: 'daily-1',
      title: 'Jogar 10 rodadas',
      description: 'Jogue 10 rodadas em qualquer jogo da plataforma.',
      reward: '20 XP + R$ 2,00 em bônus',
      progress: 4,
      maxProgress: 10,
      expiresIn: '23h 45m',
      isCompleted: false,
      isSpecial: false
    },
    {
      id: 'daily-2',
      title: 'Ganhar no Fortune Tiger',
      description: 'Ganhe pelo menos uma vez no jogo Fortune Tiger.',
      reward: '30 XP + 5 giros grátis',
      progress: 0,
      maxProgress: 1,
      expiresIn: '23h 45m',
      isCompleted: false,
      isSpecial: false
    },
    {
      id: 'daily-3',
      title: 'Completar uma cartela de bingo',
      description: 'Complete uma cartela em qualquer sala de bingo.',
      reward: '25 XP + 1 cartela grátis',
      progress: 0,
      maxProgress: 1,
      expiresIn: '23h 45m',
      isCompleted: false,
      isSpecial: false
    }
  ];
  
  // Missões semanais
  const weeklyMissions = [
    {
      id: 'weekly-1',
      title: 'Jogar 5 dias seguidos',
      description: 'Faça login e jogue pelo menos uma rodada por 5 dias consecutivos.',
      reward: '100 XP + R$ 10,00 em bônus',
      progress: 3,
      maxProgress: 5,
      expiresIn: '4d 12h',
      isCompleted: false,
      isSpecial: false
    },
    {
      id: 'weekly-2',
      title: 'Ganhar 3 vezes no Aviator',
      description: 'Ganhe 3 vezes no jogo Aviator com multiplicador acima de 2x.',
      reward: '75 XP + 10 giros grátis',
      progress: 1,
      maxProgress: 3,
      expiresIn: '4d 12h',
      isCompleted: false,
      isSpecial: false
    }
  ];
  
  // Missões especiais
  const specialMissions = [
    {
      id: 'special-1',
      title: 'Desafio Fortune Tiger',
      description: 'Ganhe 5 vezes no Fortune Tiger com o símbolo do tigre.',
      reward: '200 XP + R$ 25,00 em bônus',
      progress: 2,
      maxProgress: 5,
      expiresIn: '2d 8h',
      isCompleted: false,
      isSpecial: true
    }
  ];
  
  // Conquistas
  const achievements = [
    {
      id: 'first-win',
      title: 'Primeira Vitória',
      description: 'Ganhe sua primeira rodada em qualquer jogo da plataforma.',
      icon: '🏆',
      progress: 1,
      maxProgress: 1,
      reward: '50 pontos + R$ 5,00 em bônus',
      isCompleted: true
    },
    {
      id: 'fortune-tiger-master',
      title: 'Mestre do Fortune Tiger',
      description: 'Ganhe 50 rodadas no jogo Fortune Tiger.',
      icon: '🐯',
      progress: 32,
      maxProgress: 50,
      reward: '200 pontos + 10 giros grátis',
      isCompleted: false,
      isNew: true
    }
  ];
  
  // Handlers
  const handleMissionClaim = (id: string) => {
    console.log(`Missão ${id} recebida`);
    // Aqui seria implementada a lógica para atualizar o XP do usuário
    setCurrentXP(prev => prev + 25);
  };
  
  const handleDailyRewardClaim = (reward: any) => {
    console.log('Recompensa diária recebida:', reward);
    // Aqui seria implementada a lógica para atualizar o saldo do usuário
  };
  
  const handleLevelUp = (newLevel: number) => {
    console.log(`Nível aumentado para ${newLevel}`);
    // Aqui seria implementada a lógica para atualizar o nível do usuário
    setCurrentLevel(newLevel);
    setXpForNextLevel(prev => prev + 200); // Aumenta o XP necessário para o próximo nível
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="pt-20 pb-12 bg-gray-900">
        <div className="container-main">
          {/* Page Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">
                Central de <span className="text-green-500">Recompensas</span>
              </h1>
              <p className="text-gray-400">
                Complete missões, suba de nível e ganhe recompensas exclusivas
              </p>
            </div>
            
            <div className="mt-4 md:mt-0">
              <UserProfile 
                username="JogadorVIP"
                balance={1250.75}
                level={currentLevel}
                avatarUrl="https://via.placeholder.com/40"
              />
            </div>
          </div>
          
          {/* Main Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column - Level Progress and Daily Reward */}
            <div className="space-y-6">
              <LevelProgress 
                currentLevel={currentLevel}
                currentXP={currentXP}
                xpForNextLevel={xpForNextLevel}
                onLevelUp={handleLevelUp}
              />
              
              <DailyReward 
                onClaim={handleDailyRewardClaim}
                isLoggedIn={true}
              />
            </div>
            
            {/* Middle Column - Missions */}
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center">
                  <span className="text-green-500 mr-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                  </span>
                  Missões Diárias
                </h2>
                
                <div className="space-y-3">
                  {dailyMissions.map(mission => (
                    <Mission 
                      key={mission.id}
                      id={mission.id}
                      title={mission.title}
                      description={mission.description}
                      reward={mission.reward}
                      progress={mission.progress}
                      maxProgress={mission.maxProgress}
                      expiresIn={mission.expiresIn}
                      isCompleted={mission.isCompleted}
                      isSpecial={mission.isSpecial}
                      onClaim={handleMissionClaim}
                    />
                  ))}
                </div>
              </div>
              
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center">
                  <span className="text-blue-500 mr-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  </span>
                  Missões Semanais
                </h2>
                
                <div className="space-y-3">
                  {weeklyMissions.map(mission => (
                    <Mission 
                      key={mission.id}
                      id={mission.id}
                      title={mission.title}
                      description={mission.description}
                      reward={mission.reward}
                      progress={mission.progress}
                      maxProgress={mission.maxProgress}
                      expiresIn={mission.expiresIn}
                      isCompleted={mission.isCompleted}
                      isSpecial={mission.isSpecial}
                      onClaim={handleMissionClaim}
                    />
                  ))}
                </div>
              </div>
              
              <div>
                <h2 className="text-xl font-bold mb-4 flex items-center">
                  <span className="text-yellow-500 mr-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                  </span>
                  Missões Especiais
                </h2>
                
                <div className="space-y-3">
                  {specialMissions.map(mission => (
                    <Mission 
                      key={mission.id}
                      id={mission.id}
                      title={mission.title}
                      description={mission.description}
                      reward={mission.reward}
                      progress={mission.progress}
                      maxProgress={mission.maxProgress}
                      expiresIn={mission.expiresIn}
                      isCompleted={mission.isCompleted}
                      isSpecial={mission.isSpecial}
                      onClaim={handleMissionClaim}
                    />
                  ))}
                </div>
              </div>
            </div>
            
            {/* Right Column - Achievements */}
            <div>
              <h2 className="text-xl font-bold mb-4 flex items-center">
                <span className="text-purple-500 mr-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z" />
                  </svg>
                </span>
                Conquistas Recentes
              </h2>
              
              <div className="space-y-3">
                {achievements.map(achievement => (
                  <AchievementCard 
                    key={achievement.id}
                    id={achievement.id}
                    title={achievement.title}
                    description={achievement.description}
                    icon={achievement.icon}
                    progress={achievement.progress}
                    maxProgress={achievement.maxProgress}
                    reward={achievement.reward}
                    isCompleted={achievement.isCompleted}
                    isNew={achievement.isNew}
                  />
                ))}
                
                <div className="mt-4 text-center">
                  <a href="/achievements" className="inline-block bg-purple-600 hover:bg-purple-700 text-white font-bold py-2 px-6 rounded-md">
                    Ver Todas as Conquistas
                  </a>
                </div>
              </div>
              
              <div className="mt-8 bg-gray-800 rounded-lg p-4">
                <h3 className="font-bold mb-3">Próximos Eventos</h3>
                
                <div className="space-y-3">
                  <div className="bg-gray-700 rounded-md p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-bold">Torneio Fortune Tiger</p>
                        <p className="text-sm text-gray-400">Começa em 2 dias</p>
                      </div>
                      <div className="bg-yellow-600 text-black text-xs font-bold px-2 py-1 rounded-full">
                        R$ 10.000
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-700 rounded-md p-3">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="font-bold">Bônus de Fim de Semana</p>
                        <p className="text-sm text-gray-400">Começa em 3 dias</p>
                      </div>
                      <div className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full">
                        100% Extra
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
