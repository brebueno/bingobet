import React, { useState } from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import TournamentList from '../../components/tournaments/TournamentList';
import UserProfile from '../../components/ui/UserProfile';

export default function TournamentsPage() {
  const [activeTab, setActiveTab] = useState<'all' | 'my'>('all');
  
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="pt-20 pb-12 bg-gray-900">
        <div className="container-main">
          {/* Page Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold mb-2">
                <span className="text-yellow-500">Torneios</span> e Competições
              </h1>
              <p className="text-gray-400">
                Participe de torneios exclusivos e ganhe prêmios incríveis
              </p>
            </div>
            
            <div className="mt-4 md:mt-0">
              <UserProfile 
                username="JogadorVIP"
                balance={1250.75}
                level={5}
                avatarUrl="https://via.placeholder.com/40"
              />
            </div>
          </div>
          
          {/* Featured Tournament */}
          <div className="relative h-64 md:h-80 rounded-lg overflow-hidden mb-8 bg-cover bg-center" style={{ backgroundImage: 'url(https://via.placeholder.com/1200x400?text=Mega+Torneio+Fortune+Tiger)' }}>
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
            
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-end">
                <div>
                  <div className="bg-green-600 text-white text-xs font-bold px-2 py-1 rounded-full mb-2 inline-block">
                    Em Andamento
                  </div>
                  <h2 className="text-3xl font-bold text-white mb-1">Mega Torneio Fortune Tiger</h2>
                  <p className="text-gray-300">Termine entre os 10 primeiros e ganhe prêmios exclusivos!</p>
                </div>
                
                <div className="mt-4 md:mt-0 flex flex-col items-start md:items-end">
                  <div className="bg-yellow-600 text-black text-sm font-bold px-3 py-1 rounded-full mb-2">
                    Prêmio: R$ 50.000
                  </div>
                  <p className="text-white font-bold">Termina em: 2d 14h 35m</p>
                  
                  <button className="mt-3 bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-md">
                    Participar Agora
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          {/* Tabs */}
          <div className="flex border-b border-gray-700 mb-6">
            <button 
              className={`py-3 px-6 font-bold border-b-2 ${
                activeTab === 'all' 
                  ? 'border-yellow-500 text-white' 
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('all')}
            >
              Todos os Torneios
            </button>
            <button 
              className={`py-3 px-6 font-bold border-b-2 ${
                activeTab === 'my' 
                  ? 'border-yellow-500 text-white' 
                  : 'border-transparent text-gray-400 hover:text-white'
              }`}
              onClick={() => setActiveTab('my')}
            >
              Meus Torneios
            </button>
          </div>
          
          {/* Tournament List */}
          {activeTab === 'all' ? (
            <TournamentList />
          ) : (
            <TournamentList filter="all" category="all" showFilters={false} />
          )}
          
          {/* Tournament Info */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <span className="text-yellow-500 mr-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                </span>
                Como Funcionam os Torneios
              </h3>
              
              <p className="text-gray-300 mb-4">
                Os torneios são competições onde você pode ganhar prêmios incríveis jogando seus jogos favoritos. Cada torneio tem suas próprias regras e sistema de pontuação.
              </p>
              
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">•</span>
                  <span className="text-gray-300">Participe de torneios gratuitamente ou com taxa de entrada</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">•</span>
                  <span className="text-gray-300">Acumule pontos jogando os jogos do torneio</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">•</span>
                  <span className="text-gray-300">Suba no ranking para ganhar prêmios maiores</span>
                </li>
                <li className="flex items-start">
                  <span className="text-green-500 mr-2">•</span>
                  <span className="text-gray-300">Acompanhe seu progresso em tempo real</span>
                </li>
              </ul>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <span className="text-yellow-500 mr-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </span>
                Próximos Torneios
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center">
                  <img 
                    src="https://via.placeholder.com/50?text=Aviator" 
                    alt="Aviator" 
                    className="w-12 h-12 rounded-md object-cover"
                  />
                  <div className="ml-3 flex-1">
                    <p className="font-bold">Torneio Aviator</p>
                    <p className="text-xs text-gray-400">Começa em 2 dias</p>
                  </div>
                  <div className="bg-yellow-600 text-black text-xs font-bold px-2 py-1 rounded-full">
                    R$ 20.000
                  </div>
                </div>
                
                <div className="flex items-center">
                  <img 
                    src="https://via.placeholder.com/50?text=Bingo" 
                    alt="Bingo" 
                    className="w-12 h-12 rounded-md object-cover"
                  />
                  <div className="ml-3 flex-1">
                    <p className="font-bold">Super Bingo</p>
                    <p className="text-xs text-gray-400">Começa em 5 dias</p>
                  </div>
                  <div className="bg-yellow-600 text-black text-xs font-bold px-2 py-1 rounded-full">
                    R$ 30.000
                  </div>
                </div>
                
                <div className="flex items-center">
                  <img 
                    src="https://via.placeholder.com/50?text=Mines" 
                    alt="Mines" 
                    className="w-12 h-12 rounded-md object-cover"
                  />
                  <div className="ml-3 flex-1">
                    <p className="font-bold">Torneio Mines</p>
                    <p className="text-xs text-gray-400">Começa em 1 semana</p>
                  </div>
                  <div className="bg-yellow-600 text-black text-xs font-bold px-2 py-1 rounded-full">
                    R$ 15.000
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-6">
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <span className="text-yellow-500 mr-2">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </span>
                Vantagens VIP
              </h3>
              
              <p className="text-gray-300 mb-4">
                Jogadores VIP têm acesso a torneios exclusivos com prêmios ainda maiores e menos competição!
              </p>
              
              <div className="bg-gray-700 rounded-lg p-4 mb-4">
                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-400">Seu status</p>
                    <p className="font-bold text-yellow-500">VIP Nível 2</p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-400">Torneios exclusivos</p>
                    <p className="font-bold">3 disponíveis</p>
                  </div>
                </div>
              </div>
              
              <button className="w-full bg-yellow-600 hover:bg-yellow-700 text-black font-bold py-2 rounded-md">
                Ver Torneios VIP
              </button>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
}
