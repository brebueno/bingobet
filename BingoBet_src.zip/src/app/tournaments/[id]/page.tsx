import React, { useState } from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import TournamentDetails from '../../components/tournaments/TournamentDetails';

export default function TournamentDetailPage() {
  const [isJoined, setIsJoined] = useState(false);
  
  // Mock data for tournament details
  const tournamentData = {
    id: 'tournament-1',
    title: 'Mega Torneio Fortune Tiger',
    game: 'Fortune Tiger',
    gameImage: 'https://via.placeholder.com/800x400?text=Fortune+Tiger',
    prizePool: 50000,
    entryFee: 0,
    startTime: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
    endTime: new Date(Date.now() + 1000 * 60 * 60 * 24 * 2), // 2 days from now
    participants: [
      {
        id: 'user-1',
        username: 'TigerMaster',
        avatar: 'https://via.placeholder.com/40',
        score: 12500,
        position: 1
      },
      {
        id: 'user-2',
        username: 'LuckyPlayer',
        avatar: 'https://via.placeholder.com/40',
        score: 10800,
        position: 2
      },
      {
        id: 'current-user',
        username: 'JogadorVIP',
        avatar: 'https://via.placeholder.com/40',
        score: 9200,
        position: 3
      },
      {
        id: 'user-3',
        username: 'FortuneHunter',
        avatar: 'https://via.placeholder.com/40',
        score: 8500,
        position: 4
      },
      {
        id: 'user-4',
        username: 'BigWinner',
        avatar: 'https://via.placeholder.com/40',
        score: 7200,
        position: 5
      },
      {
        id: 'user-5',
        username: 'SlotKing',
        avatar: 'https://via.placeholder.com/40',
        score: 6800,
        position: 6
      },
      {
        id: 'user-6',
        username: 'LuckyTiger',
        avatar: 'https://via.placeholder.com/40',
        score: 5900,
        position: 7
      },
      {
        id: 'user-7',
        username: 'SpinMaster',
        avatar: 'https://via.placeholder.com/40',
        score: 5200,
        position: 8
      },
      {
        id: 'user-8',
        username: 'JackpotHunter',
        avatar: 'https://via.placeholder.com/40',
        score: 4800,
        position: 9
      },
      {
        id: 'user-9',
        username: 'SlotPro',
        avatar: 'https://via.placeholder.com/40',
        score: 4200,
        position: 10
      },
      {
        id: 'user-10',
        username: 'GoldenSpin',
        avatar: 'https://via.placeholder.com/40',
        score: 3800,
        position: 11
      },
      {
        id: 'user-11',
        username: 'TigerFan',
        avatar: 'https://via.placeholder.com/40',
        score: 3500,
        position: 12
      }
    ],
    rules: [
      'Jogue o Fortune Tiger para acumular pontos',
      'Cada R$ 1,00 apostado vale 1 ponto',
      'Ganhos com o símbolo do tigre valem pontos em dobro',
      'Ativação do recurso Tiger\'s Claw concede 500 pontos bônus',
      'Apenas apostas reais contam para o torneio',
      'O ranking é atualizado a cada 5 minutos',
      'Em caso de empate, o jogador que atingiu a pontuação primeiro tem vantagem'
    ],
    prizes: [
      {
        position: '1º Lugar',
        reward: 'R$ 20.000 + 100 Giros Grátis'
      },
      {
        position: '2º Lugar',
        reward: 'R$ 10.000 + 50 Giros Grátis'
      },
      {
        position: '3º Lugar',
        reward: 'R$ 5.000 + 25 Giros Grátis'
      },
      {
        position: '4º - 10º Lugar',
        reward: 'R$ 1.000 + 10 Giros Grátis'
      },
      {
        position: '11º - 20º Lugar',
        reward: 'R$ 500 + 5 Giros Grátis'
      },
      {
        position: '21º - 50º Lugar',
        reward: 'R$ 100 + 2 Giros Grátis'
      }
    ]
  };
  
  // Handle join tournament
  const handleJoinTournament = (id: string) => {
    console.log(`Joining tournament ${id}`);
    setIsJoined(true);
  };
  
  // Handle leave tournament
  const handleLeaveTournament = (id: string) => {
    console.log(`Leaving tournament ${id}`);
    setIsJoined(false);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Tournament Details */}
      <TournamentDetails 
        id={tournamentData.id}
        title={tournamentData.title}
        game={tournamentData.game}
        gameImage={tournamentData.gameImage}
        prizePool={tournamentData.prizePool}
        entryFee={tournamentData.entryFee}
        startTime={tournamentData.startTime}
        endTime={tournamentData.endTime}
        participants={tournamentData.participants}
        rules={tournamentData.rules}
        prizes={tournamentData.prizes}
        isJoined={isJoined}
        onJoin={handleJoinTournament}
        onLeave={handleLeaveTournament}
      />

      {/* Footer */}
      <Footer />
    </div>
  );
}
