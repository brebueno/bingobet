import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import BingoCard from '../../components/bingo/BingoCard';

export default function BingoPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Bingo Hero */}
      <section className="bg-gradient-to-r from-green-900 to-green-800 py-12">
        <div className="container-main text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Salas de <span className="text-yellow-500">Bingo</span>
          </h1>
          <p className="text-xl mb-6 max-w-3xl mx-auto">
            Escolha entre nossas diversas salas de bingo e divirta-se com milhares de jogadores online. Prêmios incríveis esperam por você!
          </p>
        </div>
      </section>

      {/* Bingo Rooms */}
      <section className="py-12 bg-gray-900">
        <div className="container-main">
          <h2 className="text-2xl font-bold mb-6">
            Bingo Tradicional <span className="text-green-500">(90 bolas)</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            <BingoCard 
              variant="traditional"
              title="Sala Ouro"
              description="Cartela R$5"
              countdown="01:30"
              players={87}
              prize="R$ 2.350"
            />
            
            <BingoCard 
              variant="traditional"
              title="Sala Prata"
              description="Cartela R$2"
              countdown="03:45"
              players={124}
              prize="R$ 1.120"
            />
            
            <BingoCard 
              variant="traditional"
              title="Sala Bronze"
              description="Cartela R$1"
              countdown="02:15"
              players={215}
              prize="R$ 850"
            />
          </div>

          <h2 className="text-2xl font-bold mb-6">
            Bingo Americano <span className="text-green-500">(75 bolas)</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
            <BingoCard 
              variant="american"
              title="Sala Vegas"
              description="Cartela R$10"
              countdown="04:20"
              players={65}
              prize="R$ 3.200"
            />
            
            <BingoCard 
              variant="american"
              title="Sala Miami"
              description="Cartela R$5"
              countdown="06:10"
              players={92}
              prize="R$ 1.850"
            />
            
            <BingoCard 
              variant="american"
              title="Sala Texas"
              description="Cartela R$2"
              countdown="02:50"
              players={143}
              prize="R$ 980"
            />
          </div>

          <h2 className="text-2xl font-bold mb-6">
            Bingo Blitz <span className="text-green-500">(Jogos Rápidos)</span>
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <BingoCard 
              variant="blitz"
              title="Sala Relâmpago"
              description="Cartela R$2"
              countdown="00:45"
              players={178}
              prize="R$ 1.250"
            />
            
            <BingoCard 
              variant="blitz"
              title="Sala Turbo"
              description="Cartela R$5"
              countdown="00:30"
              players={132}
              prize="R$ 2.500"
            />
            
            <BingoCard 
              variant="blitz"
              title="Sala Flash"
              description="Cartela R$10"
              countdown="00:15"
              players={95}
              prize="R$ 4.800"
            />
          </div>
        </div>
      </section>

      {/* How to Play */}
      <section className="py-12 bg-gray-800">
        <div className="container-main">
          <h2 className="text-3xl font-bold mb-8 text-center">
            Como <span className="text-green-500">Jogar</span>
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="card text-center">
              <div className="h-16 w-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">1</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Escolha uma Sala</h3>
              <p className="text-gray-400">
                Selecione entre nossas diversas salas de bingo com diferentes valores de cartela e prêmios.
              </p>
            </div>
            
            <div className="card text-center">
              <div className="h-16 w-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">2</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Compre Cartelas</h3>
              <p className="text-gray-400">
                Adquira quantas cartelas desejar. Quanto mais cartelas, maiores suas chances de ganhar!
              </p>
            </div>
            
            <div className="card text-center">
              <div className="h-16 w-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold">3</span>
              </div>
              <h3 className="text-xl font-bold mb-2">Divirta-se e Ganhe</h3>
              <p className="text-gray-400">
                Acompanhe o sorteio em tempo real, marque seus números e grite "Bingo!" quando completar o padrão vencedor.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <Footer />
    </div>
  );
}
