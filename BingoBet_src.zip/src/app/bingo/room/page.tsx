import React from 'react';
import Header from '../../components/layout/Header';
import Footer from '../../components/layout/Footer';
import BingoCard from '../../components/bingo/BingoCard';

export default function BingoRoomPage() {
  return (
    <div className="min-h-screen">
      {/* Header */}
      <Header />

      {/* Bingo Room */}
      <div className="bg-gray-900 py-8">
        <div className="container-main">
          {/* Room Header */}
          <div className="bg-gradient-to-r from-green-900 to-green-800 rounded-lg p-6 mb-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div>
                <h1 className="text-3xl font-bold mb-2">Sala Tradicional - Ouro</h1>
                <p className="text-xl text-gray-300">Bingo 90 bolas</p>
              </div>
              <div className="mt-4 md:mt-0 flex items-center space-x-6">
                <div className="text-center">
                  <p className="text-sm text-gray-300">Jogadores</p>
                  <p className="text-2xl font-bold">124</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-300">Prêmio Atual</p>
                  <p className="text-2xl font-bold text-yellow-500">R$ 1.250</p>
                </div>
                <div className="text-center">
                  <p className="text-sm text-gray-300">Próximo Sorteio</p>
                  <p className="text-2xl font-bold text-green-500">02:45</p>
                </div>
              </div>
            </div>
          </div>

          {/* Main Game Area */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Left Column - Bingo Cards */}
            <div className="lg:col-span-2">
              <div className="bg-gray-800 rounded-lg p-6 mb-6">
                <h2 className="text-xl font-bold mb-4">Suas Cartelas</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Bingo Card 1 */}
                  <div className="bg-white rounded-lg p-3">
                    <div className="grid grid-cols-5 gap-2">
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">B</div>
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">I</div>
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">N</div>
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">G</div>
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">O</div>
                      
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">3</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">17</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">31</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">48</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">61</div>
                      
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">7</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">22</div>
                      <div className="bg-red-500 rounded-md p-2 text-center text-white font-bold">FREE</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">53</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">67</div>
                      
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">12</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">26</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">39</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">55</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">72</div>
                      
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">14</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">29</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">43</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">59</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">75</div>
                    </div>
                  </div>
                  
                  {/* Bingo Card 2 */}
                  <div className="bg-white rounded-lg p-3">
                    <div className="grid grid-cols-5 gap-2">
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">B</div>
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">I</div>
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">N</div>
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">G</div>
                      <div className="bg-green-600 rounded-md p-1 text-center font-bold">O</div>
                      
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">5</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">19</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">33</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">47</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">64</div>
                      
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">8</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">24</div>
                      <div className="bg-red-500 rounded-md p-2 text-center text-white font-bold">FREE</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">52</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">69</div>
                      
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">11</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">27</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">38</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">56</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">73</div>
                      
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">15</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">28</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">44</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">58</div>
                      <div className="bg-gray-200 rounded-md p-2 text-center text-black font-bold">76</div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-between">
                  <button className="btn-secondary">Comprar Mais Cartelas</button>
                  <button className="btn-primary">Auto-Daub (Marcação Automática)</button>
                </div>
              </div>
              
              {/* Drawn Numbers */}
              <div className="bg-gray-800 rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Números Sorteados</h2>
                <div className="grid grid-cols-5 sm:grid-cols-10 gap-2">
                  <div className="bg-green-600 rounded-full w-10 h-10 flex items-center justify-center font-bold">7</div>
                  <div className="bg-green-600 rounded-full w-10 h-10 flex items-center justify-center font-bold">12</div>
                  <div className="bg-green-600 rounded-full w-10 h-10 flex items-center justify-center font-bold">24</div>
                  <div className="bg-green-600 rounded-full w-10 h-10 flex items-center justify-center font-bold">31</div>
                  <div className="bg-green-600 rounded-full w-10 h-10 flex items-center justify-center font-bold">43</div>
                  <div className="bg-gray-700 rounded-full w-10 h-10 flex items-center justify-center font-bold">?</div>
                  <div className="bg-gray-700 rounded-full w-10 h-10 flex items-center justify-center font-bold">?</div>
                  <div className="bg-gray-700 rounded-full w-10 h-10 flex items-center justify-center font-bold">?</div>
                  <div className="bg-gray-700 rounded-full w-10 h-10 flex items-center justify-center font-bold">?</div>
                  <div className="bg-gray-700 rounded-full w-10 h-10 flex items-center justify-center font-bold">?</div>
                </div>
                
                <div className="mt-6">
                  <div className="bg-yellow-600 rounded-lg p-4 text-center">
                    <h3 className="text-lg font-bold mb-2">Próximo número em:</h3>
                    <p className="text-3xl font-bold">00:15</p>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Right Column - Chat and Winners */}
            <div>
              {/* Chat */}
              <div className="bg-gray-800 rounded-lg p-6 mb-6">
                <h2 className="text-xl font-bold mb-4">Chat da Sala</h2>
                <div className="bg-gray-900 rounded-lg p-4 h-64 overflow-y-auto mb-4">
                  <div className="mb-3">
                    <span className="text-green-500 font-bold">Maria123: </span>
                    <span className="text-gray-300">Boa sorte a todos! 🍀</span>
                  </div>
                  <div className="mb-3">
                    <span className="text-yellow-500 font-bold">João_Bingo: </span>
                    <span className="text-gray-300">Quase lá! Só falta o 64 para bingo!</span>
                  </div>
                  <div className="mb-3">
                    <span className="text-blue-500 font-bold">CarolGamer: </span>
                    <span className="text-gray-300">Alguém sabe quando começa o torneio de truco?</span>
                  </div>
                  <div className="mb-3">
                    <span className="text-red-500 font-bold">Admin: </span>
                    <span className="text-gray-300">O torneio de truco começa às 20h. Boa sorte no bingo!</span>
                  </div>
                  <div className="mb-3">
                    <span className="text-purple-500 font-bold">BingoMaster: </span>
                    <span className="text-gray-300">Vamos lá pessoal! 🎯</span>
                  </div>
                </div>
                <div className="flex">
                  <input 
                    type="text" 
                    className="flex-1 bg-gray-700 rounded-l-md px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-green-500"
                    placeholder="Digite sua mensagem..."
                  />
                  <button className="bg-green-600 hover:bg-green-700 text-white font-bold px-4 py-2 rounded-r-md transition-colors">
                    Enviar
                  </button>
                </div>
              </div>
              
              {/* Winners */}
              <div className="bg-gray-800 rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Últimos Vencedores</h2>
                <div className="space-y-4">
                  <div className="bg-gray-700 rounded-lg p-3 flex justify-between items-center">
                    <div>
                      <p className="font-bold">MariaLuiza</p>
                      <p className="text-sm text-gray-400">Sala Ouro - 15:30</p>
                    </div>
                    <div className="text-yellow-500 font-bold">R$ 1.850</div>
                  </div>
                  <div className="bg-gray-700 rounded-lg p-3 flex justify-between items-center">
                    <div>
                      <p className="font-bold">Carlos_B</p>
                      <p className="text-sm text-gray-400">Sala Prata - 14:45</p>
                    </div>
                    <div className="text-yellow-500 font-bold">R$ 950</div>
                  </div>
                  <div className="bg-gray-700 rounded-lg p-3 flex justify-between items-center">
                    <div>
                      <p className="font-bold">JulianaS</p>
                      <p className="text-sm text-gray-400">Sala Blitz - 14:15</p>
                    </div>
                    <div className="text-yellow-500 font-bold">R$ 2.500</div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <button className="btn-accent w-full">
                    BINGO!
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <Footer />
    </div>
  );
}
